from BasicClasses.functions import *
from NeutralChampions.Shrek.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.55, 0.6, 0.65, 0.67, 0.7],    # Przelicznik AD rzucającego
                           [0.03, 0.04, 0.05, 0.07, 0.08],  # Przelicznik MAXHP rzucającego
                           [0, 1, 1, 1, 2]]                 # Czas wyciszenia celu
ABILITYQ_SUPER_VALUES   = [[0.6, 0.65, 0.7, 0.75, 0.8],     # Przelicznik AD rzucającego
                           [0.05, 0.06, 0.08, 0.09, 0.1],   # Przelicznik MAXHP rzucającego,
                           [1, 1, 1, 2, 2],                 # Czas wyciszenia celu
                           [1, 1, 2, 2, 3]]                 # Czas trwania furii rzucającego
ABILITYW_VALUES         = [[0.65, 0.7, 0.75, 0.8, 0.82],    # Przelicznik AP rzucającego
                           [100, 120, 150, 170, 200],       # Wartość podstawowa obrażeń
                           [0.15, 0.2, 0.25, 0.3, 0.32],    # Przelicznik MS rzucającego
                           [0, 1, 1, 1, 1]]                 # Długość ogłuszenia celu
ABILITYW_SUPER_VALUES   = [[0.7, 0.75, 0.8, 0.85, 0.9],     # Przelicznik AP rzucającego
                           [150, 200, 230, 250, 280],       # Wartość podstawowa obrażeń
                           [0.24, 0.28, 0.32, 0.36, 0.4],   # Przelicznik MS rzucającego
                           [1, 1, 1, 1, 2]]                 # Długość ogłuszenia celu
ABILITYE_VALUES         = [[0.5, 0.55, 0.6, 0.65, 0.7],     # Procent przywrócenia brakującego HP
                           [0, 1, 1, 1, 2],                 # Długość antybiotyku rzucającego
                           [0, 1, 1, 1, 2],                 # Długość świętej tarczy rzucjącego
                           [0, 1, 1, 1, 2]]                 # Długość pobudzenia rzucającego
ABILITYE_SUPER_VALUES   = [[0.6, 0.65, 0.7, 0.75, 0.8],     # Procent przywrócenia brakującego HP
                           [1, 1, 1, 2, 2],                 # Długość antybiotyku rzucającego
                           [1, 1, 1, 2, 3],                 # Długość świętej tarczy rzucjącego
                           [1, 1, 1, 2, 3],                 # Długość pobudzenia rzucającego
                           [0.2, 0.25, 0.3, 0.35, 0.4]]     # Przelicznik brakującego zdrowia zamienianego na obrażenia
ABILITYR_VALUES         = [[0.5, 0.6, 0.7, 0.8, 0.9],       # Przelicznik AD rzucającego
                           [0.12, 0.15, 0.2, 0.25, 0.3],    # Przelicznik MAXHP rzucającego
                           [1, 1, 2, 2, 3]]                 # Czas trwania procentowego rozbrojenia
PASSIVE_VALUES          = [[1, 1, 1, 1, 1],                 # Aktywne zatrucie dla wszystkich
                           [0, 1, 1, 1, 1],                 # Aktywne zawieszenie broni dla wszystkich
                           [0, 0, 0, 0, 1]]                 # Aktywne superzdolności dla rzucającego


def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYQ_VALUES[0][ability.getLevel()]
    dmg += user.getMAXHP() * ABILITYQ_VALUES[1][ability.getLevel()]
    target.getEffectByKey(EFFECT_SILENCE).changeCount(int(ABILITYQ_VALUES[2][ability.getLevel()]))
    user.getADDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()]
    dmg += user.getMAXHP() * ABILITYQ_SUPER_VALUES[1][ability.getLevel()]
    target.getEffectByKey(EFFECT_SILENCE).changeCount(int(ABILITYQ_SUPER_VALUES[2][ability.getLevel()]))
    user.getEffectByKey(EFFECT_FURY).changeCount(int(ABILITYQ_SUPER_VALUES[3][ability.getLevel()]))
    user.getADDMG(dmg=dmg, target=target)
    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYW_VALUES[0][ability.getLevel()]
    dmg += ABILITYW_VALUES[1][ability.getLevel()] * 0.1
    dmg += user.getMS() * ABILITYW_VALUES[2][ability.getLevel()]
    target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYW_VALUES[3][ability.getLevel()]))
    user.getADDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    dmg += ABILITYW_SUPER_VALUES[1][ability.getLevel()] * 0.1
    dmg += user.getMS() * ABILITYW_SUPER_VALUES[2][ability.getLevel()]
    target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYW_SUPER_VALUES[3][ability.getLevel()]))
    target.getEffectByKey(EFFECT_BLEED).changeCount(int(ABILITYW_SUPER_VALUES[4][ability.getLevel()]))
    user.getADDMG(dmg=dmg, target=target)
    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    heal = (user.getMAXHP() - user.getHP()) * ABILITYE_VALUES[0][ability.getLevel()]
    user.getEffectByKey(EFFECT_ANTIBIOTIC).changeCount(int(ABILITYE_VALUES[1][ability.getLevel()]))
    user.getEffectByKey(EFFECT_SACRED_SHIELD).changeCount(int(ABILITYE_VALUES[2][ability.getLevel()]))
    user.getEffectByKey(EFFECT_STIMULATION).changeCount(int(ABILITYE_VALUES[3][ability.getLevel()]))
    user.changeStat(STAT_HP, heal)
    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    heal = (user.getMAXHP() - user.getHP()) * ABILITYE_SUPER_VALUES[0][ability.getLevel()]
    user.getEffectByKey(EFFECT_ANTIBIOTIC).changeCount(int(ABILITYE_SUPER_VALUES[1][ability.getLevel()]))
    user.getEffectByKey(EFFECT_SACRED_SHIELD).changeCount(int(ABILITYE_SUPER_VALUES[2][ability.getLevel()]))
    user.getEffectByKey(EFFECT_STIMULATION).changeCount(int(ABILITYE_SUPER_VALUES[3][ability.getLevel()]))
    user.changeStat(STAT_HP, heal)
    dmg = heal * ABILITYE_SUPER_VALUES[4][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)
    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYR_VALUES[0][ability.getLevel()] + user.getMAXHP() * ABILITYR_VALUES[1][ability.getLevel()]
    target.getEffectByKey(EFFECT_PERC_DISARM).changeCount(int(ABILITYR_VALUES[2][ability.getLevel()]))
    user.getADDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)