from BasicClasses.functions import *
from BasicClasses.dictionary import *
from NeutralChampions.Shrek.abilities import *
from BasicClasses.Effect.functions import *

class Shrek(EmptyHero):

    def __init__(self, ID, players):
        super().__init__(ID=0, Name="Shrek",
                         HP=400, MAXHP=400, HPREG=10,
                         Mana=120, MAXMana=120, ManaREG=10,
                         AD=20, AP=20, AR=20, MR=20,
                         AS=1.15, CRIT=10, MS=45, GOLD=2000)

        self.preparePlayer(ID, players)

        self.getAbilities().remove(self.getAbilityByIndex(4))
        self.getAbilities().remove(self.getAbilityByIndex(3))

        # SpellQ
        ability = Ability(name="Krojenie Cebuli", cost=0, cd=2, maxLevel=5)
        # self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Rzut Osłem", cost=0, cd=3, maxLevel=5)
        # self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Pomocna Fiona", cost=0, cd=2, maxLevel=5)
        # self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Ryk Ogra", cost=0, cd=5, maxLevel=5)
        # self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Swojskie Bagno", passive=True, maxLevel=5)
        # self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Kibelek*", STAT_HP: 50, STAT_MAXHP: 50,
                                 STAT_HPREG: 10, STAT_AR: 15, STAT_GOLD: 1400}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Smoczy Ogon", STAT_AR: 20, STAT_MR: 20,
                                 STAT_MAXHP: 70, STAT_GOLD: 1500}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Smakowity Udziec", STAT_HPREG: 10, STAT_MANAREG: 10,
                                 STAT_AS: 0.3, STAT_GOLD: 1200}, autoGold=False)

        self.setStacks(random.randint(1, 5))
        self.getAbilityByIndex(3).setLevel(self.getStacks() - 1)
        self.getAbilityByIndex(4).setLevel(self.getStacks() - 1)
        self.getAbilityByIndex(5).setLevel(self.getStacks() - 1)
        self.getAbilityByIndex(6).setLevel(self.getStacks() - 1)
        self.getAbilityByIndex(7).setLevel(self.getStacks() - 1)
        for stat in STAT_KEYS:
            self.changeStat(stat, self.getStat(stat) * 0.05 * self.getStacks())


    def startTurn(self):
        if not self.isAlive():
            return
        lineSeparator()
        passingEffects(self)
        for player in self.getPlayers():
            if player != self:
                player.getEffectByKey(EFFECT_TRUE_VISION).changeCount(1)
                if PASSIVE_VALUES[0][self.getAbilityByIndex(7).getLevel()] != 0:
                    if player.getEffectByKey(EFFECT_POISON) == 0:
                        player.getEffectByKey(EFFECT_POISON).changeCount(1)
                    player.getEffectByKey(EFFECT_POISON).setCount(2)
                if PASSIVE_VALUES[1][self.getAbilityByIndex(7).getLevel()] != 0:
                    if player.getEffectByKey(EFFECT_CEASEFIRE) == 0:
                        player.getEffectByKey(EFFECT_CEASEFIRE).changeCount(1)
                    player.getEffectByKey(EFFECT_CEASEFIRE).setCount(2)
        if PASSIVE_VALUES[2][self.getAbilityByIndex(7).getLevel()] != 0:
            self.getEffectByKey(EFFECT_POWER_ABILITY).setCount(1)


        self.lobby()

    def lobby(self):
        action = random.randint(0, 6)
        if action == 0:
            self.farm(10)
        elif action == 1:
            target = locateEnemy(self, autoTarget=True)
            self.getADDMG(self.getAD(), target, ARperc=0.7, CRITLuck=50)
        elif action == 2:
            print("Obrona")
            self.changeStat(STAT_AR, 3 * self.getStacks())
            self.changeStat(STAT_MR, 3 * self.getStacks())
        elif action == 3:
            self.spellQ(self.getAbilityByIndex(3))
        elif action == 4:
            self.spellW(self.getAbilityByIndex(4))
        elif action == 5:
            self.spellE(self.getAbilityByIndex(5))
        elif action == 6:
            self.spellR(self.getAbilityByIndex(6))

    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self, autoTarget=True)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self, autoTarget=True)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityW(user=self, target=target, ability=ability)
                else:
                    abilityW(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                target = locateEnemy(self, autoTarget=True)
                if target != None:
                    superAbilityE(user=self, target=target, ability=ability)
                else:
                    self.lobby()
            else:
                abilityE(user=self, ability=ability)
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self, autoTarget=True)
            if target != None:
                abilityR(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

