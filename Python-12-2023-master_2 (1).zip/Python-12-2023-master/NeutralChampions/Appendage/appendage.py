from BasicClasses.functions import *
from BasicClasses.dictionary import *

class Appendage(EmptyHero):

    def __init__(self, Master, ID, players, Name="Przyboczny",
                 HP=0, MAXHP=0, HPREG=0,
                 Mana=0, MAXMana=0, ManaREG=0,
                 AD=0, AP=0, AR=0, MR=0,
                 AS=0, CRIT=0, MS=0, GOLD=0):
        super().__init__(ID=ID, Name=Name,
                         HP=HP, MAXHP=MAXHP, HPREG=HPREG,
                         Mana=Mana, MAXMana=MAXMana, ManaREG=ManaREG,
                         AD=AD, AP=AP, AR=AR, MR=MR,
                         AS=AS, CRIT=CRIT, MS=MS, GOLD=GOLD)

        self.preparePlayer(ID, players)

        self.setName(self.getName() + " - " + Master.getName())

        self.getAbilities().remove(self.getAbilityByIndex(4))
        self.getAbilities().remove(self.getAbilityByIndex(3))
        self.getAbilities().remove(self.getAbilityByIndex(0))

        self.master = Master

    def appendageBuff(self, perc: float = 1):
        for stat in STAT_KEYS:
            self.changeStat(stat, self.getStat(stat) * perc)

    def acionSwitch(self, action):
        if action == 1:
            target = locateEnemy(self)
            if target != None:
                if target == self.master:
                    print("Próbowałeś zaatakować swojego pana?")
                else:
                    self.getTrueDMG(self.getAD(), target)
            else:
                self.lobby()
        elif action == 2:
            self.getEffectByKey(EFFECT_DEFENSE_OF_MR).changeCount(1)
        else:
            self.lobby()

    def statLimit(self):
        if self.getHP() <= 0:
            self.master.officerDerecList.remove(self)
            self.getPlayers().remove(self)
            for player in self.getPlayers():
                if player != self:
                    player.setPlayers(self.getPlayers())