from BasicClasses.Event.functions import *
from mainFunctions import *

def sortPLayers(players):
    alive = []
    dead = []
    for player in players:
        index = 0
        if player.isAlive():
            for i in alive:
                if i.getMS() > player.getMS():
                    index += 1
                else:
                    break
            alive.insert(index, player)
        else:
            for d in dead:
                if d.getMS() > player.getMS():
                    index += 1
                else:
                    break
            dead.insert(index, player)
    sortedPlayers = alive + dead

    for index, player in enumerate(sortedPlayers):
        player.setID(index)
    return sortedPlayers



if __name__ == '__main__':
    players = lobby()
    i = 0
    for player in players:
        i += 1
        player.preparePlayer(i, players)
        if modificationDict[MODIFICATION_GOOD_BEGINNING] != 0:
            player.changeStat(STAT_GOLD, 1500)
        if modificationDict[MODIFICATION_DOUBLE_TROUBLE] != 0:
            player.doubleStats()
            player.changeActualEventByKey(EVENT_DOUBLE_FARM, 9999)
            for item in player.getShop().items:
                item.doubleStats()
    if len(players) > 1:
        while True:
            alive = 0
            lastAlive = ""
            for player in players:
                if modificationDict[MODIFICATION_METEOR_SHOWER] != 0:
                    if random.randint(0, 100) < 15:
                        print("Meteoryt trafił " + player.getName())
                        player.changeStat(STAT_HP, -25)
                        player.getEffectByKey(EFFECT_STUN).changeCount(1)
                if modificationDict[MODIFICATION_TOXIC_FUMES] != 0:
                    print("Obrażenia od " + MODIFICATION_TOXIC_FUMES + ":")
                    dmg = player.getMAXHP() * 0.05
                    player.changeStat(STAT_HP, -dmg)
                if player.isAlive():
                    alive += 1
                    lastAlive = player.getName()
            if alive < 2:
                break
            players = sortPLayers(players)
            for player in players:
                player.setPlayers(players)
            eventId = random.randint(0, (len(EVENT_LIST) - 1) * 3)
            if modificationDict[MODIFICATION_CHAOTIC_WEATHER] != 0:
                eventId = 16
            if eventId < len(EVENT_LIST):
                eventName = EVENT_LIST[eventId]
                print("-------------------------------------------------------------------")
                print("Zdarzenie losowe - " + eventName)
                for player in players:
                    player.changeActualEventByKey(eventName, 1)
                    eventTable(player)
                print("Kliknij...", end='')
                input()
            for player in players:
                player.startTurn()
            print("-------------------------------------------------------------------")
            print("I tak minęła tura\nKliknij...\n", end='')
            for player in players:
                print("-------------------------------------------------------------------")
                input()
                print("Podsumowanie dla " + player.getName())
                player.endTurn()
                if player.isAlive() and modificationDict[MODIFICATION_ONE_SHOT_CONTEST] == 1:
                    print(player.getName() + " musi zostać pokonany w ciągu jednej tury")
                    player.setHP(player.getMAXHP())
            print("-------------------------------------------------------------------")
            players[0].printPlayers()
            print("-------------------------------------------------------------------")
            input()
            os.system("cls")
            players = players[0].getPlayers().copy()
        if lastAlive == "":
            print("-------------------------------------------------------------------")
            players = sortPLayers(players)
            players[0].printPlayers()
            print("-------------------------------------------------------------------")
            print("Tym razem nikt nie wygrał")
        else:
            print("-------------------------------------------------------------------")
            players = sortPLayers(players)
            players[0].printPlayers()
            print("-------------------------------------------------------------------")
            print("Zwycięzcą zostaje: " + lastAlive)
    else:
        print("Gra się zakończyła tak szybko, jak się zaczęła")