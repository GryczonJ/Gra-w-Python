from Heroes.Veigar.abilities import *

class Veigar(EmptyHero):
    
    def __init__(self):
        super().__init__(ID=1, Name="Veigar",
                         HP=150, MAXHP=150, HPREG=10,
                         Mana=80, MAXMana=80, ManaREG=10,
                         AD=10, AP=20, AR=10, MR=20,
                         AS=1, CRIT=0, MS=40, GOLD=550)

    def preparePlayer(self, id, players):
        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Zgubne Uderzenie", cost=10, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Czarna Materia", cost=30, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Horyzont Zdarzeń", cost=20, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Pierwotny Wybuch", cost=60, cd=4, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Moc Zła", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Zła Czapka*", STAT_AP: 50, STAT_MANAREG: 5, STAT_GOLD: 1400}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Skupienie Horyzontalne*", STAT_AP: 30, STAT_HP: 10, STAT_MAXHP: 10, STAT_GOLD: 900}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Klsepsydra*", STAT_AP: 20, STAT_MR: 10, STAT_AR: 10, STAT_GOLD: 1000}, autoGold=False)

        self.setStacks(0)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityQ(user=self, ability=ability)
            else:
                abilityQ(user=self, ability=ability)
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityW(user=self, target=target, ability=ability)
                else:
                    abilityW(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityE(user=self, ability=ability)
            else:
                target = locateEnemy(self)
                if target != None:
                    abilityE(user=self, target=target, ability=ability)
                else:
                    self.lobby()
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                abilityR(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

