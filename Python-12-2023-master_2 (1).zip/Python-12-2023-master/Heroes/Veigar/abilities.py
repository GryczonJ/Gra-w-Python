from BasicClasses.functions import *
from Heroes.Veigar.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.9, 1, 1.1, 1.15, 1.2],        # Przelicznik AP rzucającego
                           [20, 18, 16, 14, 13]]            # Przelicznik złoto -> ładunek
ABILITYQ_SUPER_VALUES   = [[1.2, 1.25, 1.35, 1.4, 1.45],    # Przelicznik AP rzucającego
                           [17, 15, 13, 12, 11]]            # Przelicznik złoto -> ładunek
ABILITYW_VALUES         = [[0.7, 0.72, 0.75, 0.8, 0.85],    # Przelicznik AP rzucającego
                           [40, 45, 50, 55, 60],            # Stała wartość obrażeń
                           [22, 21, 20, 18, 14]]            # Liczba staków, potrzebna do skrócenia czasu donowienia
ABILITYW_SUPER_VALUES   = [[0.9, 1, 1.1, 1.2, 1.3],         # Przelicznik AP rzucającego
                           [40, 50, 55, 60, 65],            # Stała wartość obrażeń
                           [20, 18, 16, 14, 13]]            # Liczba staków, potrzebna do skrócenia czasu donowienia
ABILITYE_VALUES         = [[1, 1, 1, 1, 2]]                 # Przebicie odporności na magię
ABILITYE_SUPER_VALUES   = [[1, 1, 1, 1, 1]]                 # Przebicie odporności na magię
ABILITYR_VALUES         = [[0.01, 0.015, 0.02],             # Przelicznik AP za każdy 1% brakującego zdrowia
                           [30, 40, 50],                    # Stała wartość obrażeń
                           [0.6, 0.7, 0.8]]                 # Przelicznik AP rzucającego
PASSIVE_VALUES          = [[1, 1.5, 2]]                     # Liczba AP zapewniana przez 1 ładunek

def abilityQ(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    targetType = chooseTargetType()
    if targetType == 2:
        target = locateEnemy(user)
        if target != None:
            dmg = user.getAP() * ABILITYQ_VALUES[0][ability.getLevel()]
            user.getAPDMG(dmg=dmg, target=target)

            user.abilityUsed(ability)
        else:
            user.lobby()
    else:
        prevGold = user.getGOLD()
        user.farm(2)
        nextGold = user.getGOLD()
        stacks = math.ceil((nextGold - prevGold) / ABILITYQ_VALUES[1][ability.getLevel()])
        user.changeStacks(stacks)
        stacks_msg1(stacks)
        user.changeStat(STAT_AP, stacks * PASSIVE_VALUES[0][user.getAbilityByIndex(9).getLevel()])
        
        user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    targetType = chooseTargetType()
    if targetType == 2:
        target = locateEnemy(user)
        if target != None:
            dmg = user.getAP() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()]
            user.getAPDMG(dmg=dmg, target=target)

            user.abilityUsed(ability)
        else:
            user.lobby()
    else:
        prevGold = user.getGOLD()
        user.farm()
        nextGold = user.getGOLD()
        stacks = math.ceil((nextGold - prevGold) / ABILITYQ_SUPER_VALUES[1][ability.getLevel()])
        user.changeStacks(stacks)
        stacks_msg1(stacks)
        user.changeStat(STAT_AP, stacks * PASSIVE_VALUES[0][user.getAbilityByIndex(9).getLevel()])

        user.abilityUsed(ability)
        user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYW_VALUES[0][ability.getLevel()] + ABILITYW_VALUES[1][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)

    cooldown = math.ceil(ability.getDefCD() - (user.getStacks() / ABILITYW_VALUES[2][ability.getLevel()]))
    if cooldown < 0:
        cooldown = 0
    user.abilityUsed(ability)
    ability.setCurrCD(cooldown)
    abilityCD_msg1(abilityName=ability.getName(), changeCD=cooldown, defaultCD=ability.getDefCD())


def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYW_SUPER_VALUES[0][ability.getLevel()] + ABILITYW_SUPER_VALUES[1][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)

    cooldown = math.ceil(ability.getDefCD() - (user.getStacks() / ABILITYW_SUPER_VALUES[2][ability.getLevel()]))
    if cooldown < 0:
        cooldown = 0
    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)
    ability.setCurrCD(cooldown)
    abilityCD_msg1(abilityName=ability.getName(), changeCD=cooldown, defaultCD=ability.getDefCD())



def abilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYE_VALUES[0][ability.getLevel()]))

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    for player in user.getPlayers():
        if player == user:
            continue
        player.getEffectByKey(EFFECT_STUN).changeCount(ABILITYE_SUPER_VALUES[0][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    dmg = (target.getMAXHP() - target.getHP()) / target.getMAXHP() * 100 * ABILITYR_VALUES[0][ability.getLevel()] * user.getAP()
    dmg += ABILITYR_VALUES[1][ability.getLevel()] + user.getAP() * ABILITYR_VALUES[2][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)