from Heroes.ChoGath.abilities import *

class ChoGath(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="ChoGath",
                         HP=180, MAXHP=180, HPREG=10,
                         Mana=70, MAXMana=70, ManaREG=8,
                         AD=20, AP=10, AR=20, MR=20,
                         AS=1.1, CRIT=0, MS=45, GOLD=600)

    def preparePlayer(self, id, players):
            super().preparePlayer(id, players)

            # SpellQ
            ability = Ability(name="Pęknięcie", cost=30, cd=3, maxLevel=5)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
            self.addAbility(ability)

            # SpellW
            ability = Ability(name="Dziki Krzyk", cost=50, cd=3, maxLevel=5)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)

            self.addAbility(ability)

            # SpellE
            ability = Ability(name="Worpalowe Kolce", cost=15, cd=2, maxLevel=5)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
            self.addAbility(ability)

            # SpellR
            ability = Ability(name="Opędzlowanie", cost=70, cd=4, maxLevel=3)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
            self.addAbility(ability)

            # Passive
            ability = Ability(name="Mięsożerca", passive=True, maxLevel=3)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
            self.addAbility(ability)

            self.playerShop.addItem({STAT_NAME: "Maska Odchłani*", STAT_MR: 40, STAT_HP: 30, STAT_MAXHP: 30, STAT_MANAREG: 10, STAT_GOLD: 2400}, autoGold=False)
            self.playerShop.addItem({STAT_NAME: "Płomienna Peleryna*", STAT_HP: 50, STAT_MAXHP: 50, STAT_HPREG: 10, STAT_GOLD: 1400}, autoGold=False)
            self.playerShop.addItem({STAT_NAME: "Kolczasta Kolczuga*", STAT_AR: 40, STAT_MR: 20, STAT_GOLD: 1650}, autoGold=False)

            self.setStacks(0)

    def farm(self, staticRepeat: int = 0, minions: None | list = None):
        repeat = math.ceil((2 * self.getAS()) + (self.getMS() * 0.01))
        if staticRepeat != 0:
            repeat = staticRepeat
        self.changeStat(STAT_HP, repeat * PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])
        super().farm(staticRepeat)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityW(user=self, target=target, ability=ability)
                else:
                    abilityW(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityE(user=self, target=target, ability=ability)
                else:
                    abilityE(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            abilityR(user=self, ability=ability)
        else:
            self.lobby()