from BasicClasses.functions import *
from Heroes.ChoGath.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[1, 1.15, 1.2, 1.25, 1.3],       # Przelicznik AP rzucającego
                           [1, 1, 1, 1, 2]]                 # Długość ogłuszenia celu
ABILITYQ_SUPER_VALUES   = [[1, 1.1, 1.2, 1.3, 1.4],         # Przelicznik AP rzucającego
                           [1, 1, 1, 2, 2],                 # Długość ogłuszenia celu
                           [40, 45, 50, 55, 60],            # Szansa na objecie pozostałych graczy (w procentach)
                           [1, 1, 1, 1, 1]]                 # Długość ogłuszenia pozostałych
ABILITYW_VALUES         = [[0.5, 0.55, 0.6, 0.65, 0.7],     # Przelicznik AP rzucającego
                           [1, 1, 1, 1, 2]]                 # Długość wyciszenia celu
ABILITYW_SUPER_VALUES   = [[0.5, 0.6, 0.7, 0.8, 0.9],       # Przelicznik AP rzucającego
                           [1, 1, 1, 1, 2],                 # Długość wyciszenia celu
                           [70, 75, 80, 85, 90],            # Szansa na objecie pozostałych graczy (w procentach)
                           [1, 1, 1, 1, 1]]                 # Długość wyciszenia pozostałych
ABILITYE_VALUES         = [[0.1, 0.12, 0.14, 0.16, 0.18],   # Przelicznik MAXHP celu
                           [1, 0.98, 0.96, 0.94, 0.92]]     # Przebicie odporności na magię
ABILITYE_SUPER_VALUES   = [[0.2, 0.22, 0.24, 0.26, 0.28],   # Przelicznik MAXHP celu
                           [0.8, 0.78, 0.76, 0.74, 0.72]]   # Przebicie odporności na magię
ABILITYR_VALUES         = [[0.15, 0.17, 0.19],              # Przelicznik MAXHP rzucającego
                           [0.3, 0.32, 0.34],               # Przelicznik AP rzucającego
                           [2, 2, 3],                       # Liczba ładunków za stwory (2 razy więcej za bohatera)
                           [15, 17, 20]]                    # Liczba MAXHP za każdy ładunek
PASSIVE_VALUES          = [[5, 8, 10]]                      # Liczba HP przywracana po zabiciu

def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYQ_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_STUN).changeCount(ABILITYQ_VALUES[1][ability.getLevel()])


    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_STUN).changeCount(ABILITYQ_SUPER_VALUES[1][ability.getLevel()])

    for player in user.getPlayers():
        if player == user or player == target:
            continue
        if random.randint(0, 100) < ABILITYQ_SUPER_VALUES[2][ability.getLevel()]:
            user.getAPDMG(dmg=dmg, target=player)
            player.getEffectByKey(EFFECT_STUN).changeCount(ABILITYQ_SUPER_VALUES[3][ability.getLevel()])


    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYW_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_SILENCE).changeCount(int(ABILITYW_VALUES[1][ability.getLevel()]))


    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_SILENCE).changeCount(int(ABILITYW_SUPER_VALUES[1][ability.getLevel()]))

    for player in user.getPlayers():
        if player == user or player == target:
            continue
        if random.randint(0, 100) < ABILITYW_SUPER_VALUES[2][ability.getLevel()]:
            user.getAPDMG(dmg=dmg, target=player)
            player.getEffectByKey(EFFECT_SILENCE).changeCount(int(ABILITYW_SUPER_VALUES[3][ability.getLevel()]))


    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = target.getMAXHP() * ABILITYE_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target, MRperc=ABILITYE_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = target.getMAXHP() * ABILITYE_SUPER_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target, MRperc=ABILITYE_SUPER_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    targetType = chooseTargetType()
    if targetType == 2:
        target = locateEnemy(user, deadTarget=True)
        if target != None:
            dmg = user.getMAXHP() * ABILITYR_VALUES[0][ability.getLevel()] + user.getAP() * ABILITYR_VALUES[1][ability.getLevel()]
            user.getTrueDMG(dmg=dmg, target=target)
            if not target.isAlive():
                stacks = 2 * int(ABILITYR_VALUES[2][ability.getLevel()])
                stacks_msg1(stacks)
                user.changeStacks(stacks)
                stacksHP = stacks * int(ABILITYR_VALUES[3][ability.getLevel()])
                passiveHP = stacksHP * PASSIVE_VALUES[0][ability.getLevel()]
                user.changeStat(STAT_MAXHP, value=stacksHP)
                user.changeStat(STAT_HP, value=stacksHP)
                user.changeStat(STAT_HP, value=passiveHP)
            user.abilityUsed(ability)
        else:
            user.lobby()
    else:
        stacks = int(ABILITYR_VALUES[2][ability.getLevel()])
        user.farm(stacks)
        stacks_msg1(stacks)
        user.changeStacks(stacks)
        stacksHP = stacks * int(ABILITYR_VALUES[3][ability.getLevel()])
        user.changeStat(key=STAT_MAXHP, value=stacksHP)
        user.changeStat(key=STAT_HP, value=stacksHP)
        user.abilityUsed(ability)