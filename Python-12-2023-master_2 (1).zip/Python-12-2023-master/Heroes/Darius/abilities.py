from BasicClasses.functions import *
from Heroes.Darius.messages import *



##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.65, 0.7, 0.75, 0.8, 0.85],    # Przelicznik AD rzucającego
                           [25, 22, 20, 18, 15],            # Minimalna różnica MS gwarantująca trafienie ostrzem
                           [0.20, 0.22, 0.25, 0.3, 0.32],   # Przelicznik AD rzucającego (ostrze)
                           [0.1, 0.12, 0.15, 0.17, 0.2]]    # Przelicznik leczenia od brakującego zdrowia
ABILITYQ_SUPER_VALUES   = [[0.85, 0.9, 0.95, 1, 1.1],       # Przelicznik AD rzucającego
                           [20, 18, 15, 12, 10],            # Minimalna różnica MS gwarantująca trafienie ostrzem
                           [0.25, 0.3, 0.35, 0.4, 0.42],    # Przelicznik AD rzucającego (ostrze)
                           [0.2, 0.25, 0.27, 0.3, 0.4]]     # Przelicznik leczenia od brakującego zdrowia
ABILITYW_VALUES         = [[1, 1.02, 1.05, 1.1, 1.2],       # Przelicznik AD rzucającego
                           [1, 1, 1, 1, 2]]                 # Długość spowolnienia celu
ABILITYW_SUPER_VALUES   = [[1.2, 1.25, 1.3, 1.3, 1.4],      # Przelicznik AD rzucającego
                           [1, 1, 1, 1, 2]]                 # Długość spowolnienia celu
ABILITYE_VALUES         = [[1, 1, 1, 1, 2]]                 # Czas wyciszenia przeciwnika
ABILITYE_SUPER_VALUES   = [[1, 1, 1, 2, 2]]                 # Czas Wyciszenia przeciwnika
ABILITYR_VALUES         = [[35, 40, 50],                    # Bazowe obrażenia
                           [0.85, 0.95, 1.05],              # Przelicznik AD rzucającego
                           [4, 5, 6]]                       # Mnożnik obrażeń od ładunków
PASSIVE_VALUES          = [[15, 20, 25]]                    # Liczba AD przy minimum 5 ładunkach


def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYE_VALUES[0][ability.getLevel()]
    heal = 0
    if user.getMS() > target.getMS() + ABILITYQ_VALUES[1][ability.getLevel()]:
        dmg += user.getAD() * ABILITYQ_VALUES[2][ability.getLevel()]
        missing = user.getMAXHP() - user.getHP()
        heal = missing * ABILITYQ_VALUES[3][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)
    user.changeStat(STAT_HP, heal)

    user.abilityUsed(ability)
def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()]
    heal = 0
    if user.getMS() > target.getMS() + ABILITYQ_SUPER_VALUES[1][ability.getLevel()]:
        dmg += user.getAD() * ABILITYQ_SUPER_VALUES[2][ability.getLevel()]
        missing = user.getMAXHP() - user.getHP()
        heal = missing * ABILITYQ_SUPER_VALUES[3][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)
    user.changeStat(STAT_HP, heal)

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)


def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_VALUES[0][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_SLOWDOWN).changeCount(ABILITYW_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_SLOWDOWN).changeCount(int(ABILITYW_SUPER_VALUES[1][ability.getLevel()]))

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    target.getEffectByKey(EFFECT_SILENCE).changeCount(ABILITYE_SUPER_VALUES[0][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    target.getEffectByKey(EFFECT_BLEED).changeCount(1)
    target.getEffectByKey(EFFECT_SILENCE).changeCount(ABILITYE_SUPER_VALUES[0][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero,target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    stacks = target.getEffectByKey(EFFECT_BLEED).getCount()
    dmg =  ABILITYR_VALUES[0][ability.getLevel()] + user.getAD() * ABILITYR_VALUES[1][ability.getLevel()]
    dmg += ABILITYR_VALUES[2][ability.getLevel()] * stacks
    user.getTrueDMG(dmg=dmg, target=target)
    user.abilityUsed(ability)