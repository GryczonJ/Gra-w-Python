from Heroes.Darius.abilities import *
from BasicClasses.heroPattern import HeroPattern
class Darius(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Darius",
                         HP=250, MAXHP=250, HPREG=15,
                         Mana=100, MAXMana=100, ManaREG=10,
                         AD=40, AP=0, AR=20, MR=20,
                         AS=1.2,CRIT=0, MS=60, GOLD=700)

    def preparePlayer(self, id, players):
            super().preparePlayer(id, players)

            # SpellQ
            ability = Ability(name="Dziesiątkowanie", cost=30, cd=2, maxLevel=5)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
            self.addAbility(ability)

            # SpellW
            ability = Ability(name="Okaleczający Cios", cost=20, cd=2, maxLevel=5)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
            self.addAbility(ability)

            # SpellE
            ability = Ability(name="Pochwycenie", cost=35, cd=3, maxLevel=5)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
            self.addAbility(ability)

            # SpellR
            ability = Ability(name="Noxiańska Gilotyna", cost=70, cd=4, maxLevel=3)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
            self.addAbility(ability)

            # Passive
            ability = Ability(name="Krwotok", passive=True, maxLevel=3)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
            self.addAbility(ability)

            self.playerShop.addItem({STAT_NAME: "Moc Trójcy*", STAT_AD: 40, STAT_HP: 30, STAT_MAXHP: 30, STAT_MANAREG: 10, STAT_GOLD: 2000},
                                    autoGold=False)
            self.playerShop.addItem({STAT_NAME: "Pancerz Umrzyka*", STAT_HP: 30, STAT_MAXHP: 30, STAT_AD: 20, STAT_MS: 30, STAT_GOLD: 1400},
                                    autoGold=False)
            self.playerShop.addItem({STAT_NAME: "Omen Randuina*", STAT_AR: 25, STAT_MR: 30, STAT_GOLD: 1600}, autoGold=False)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityW(user=self, target=target, ability=ability)
                else:
                    abilityW(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityE(user=self, target=target, ability=ability)
                else:
                    abilityE(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                abilityR(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def getADDMG(self, dmg: float | int, target: HeroPattern, ARperc: int | float = 1.0, CRITLuck: int = 0):
        prevHP = target.getHP()
        super().getADDMG(dmg, target, ARperc)
        nextHP = target.getHP()
        if nextHP < prevHP:
            target.getEffectByKey(EFFECT_BLEED).changeCount(1)

    def getAD(self):
        for player in self.getPlayers():
            if player != self and player.getEffectByKey(EFFECT_BLEED).getCount() >= 3:
                return math.ceil(super().getAD() + PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])
        return super().getAD()

    def getStat(self, key):
        if key == STAT_AD:
            for player in self.getPlayers():
                if player != self and player.getEffectByKey(EFFECT_BLEED).getCount() >= 3:
                    return math.ceil(super().getStat(key) + PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])
        return super().getStat(key)


