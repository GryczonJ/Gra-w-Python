def ability_msg1(playerName: str, abilityName: str):
    print(playerName + " użył zdolności: " + abilityName)

def superAbility_msg1(playerName: str, abilityName: str):
    print(playerName + " użył wzmocnionej zdolności: " + abilityName)

def stacks_msg1(changeStack: int):
    print("Liczba ładunków wzrosła o: " + str(changeStack))

def powerfullAbility(playerName: str, abilityName: str):
    print(playerName + " użył potężnej zdolności: " + abilityName)

def hideEffect_msg1():
    print("Ukrycie wpływa na zmianę statystyk")

def abilityCD_msg1(abilityName: str, changeCD: int, defaultCD: int):
    print("Czas odnowienia zdolności " + abilityName + " wynosi: " + str(changeCD) + " " +
          " (bazowy: " + str(defaultCD) + ")")