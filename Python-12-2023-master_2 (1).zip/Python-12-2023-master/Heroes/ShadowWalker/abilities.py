from BasicClasses.functions import *
from Heroes.ShadowWalker.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.02, 0.025, 0.03, 0.035, 0.04],    # Przelicznik MS rzucającego
                           [0.75, 0.76, 0.77, 0.78, 0.79],      # Przelicznik AD rzucającego
                           [0.9, 0.87, 0.85, 0.83, 0.8],        # Przebicie odporności celu
                           [-30, -25, -20, -10, 0]]             # Wartość utraconych HP rzucającego
ABILITYQ_SUPER_VALUES   = [[0.03, 0.035, 0.045, 0.045, 0.05],   # Przelicznik MS rzucającego
                           [0.75, 0.76, 0.77, 0.78, 0.79],      # Przelicznik AD rzucającego
                           [0.85, 0.83, 0.81, 0.79, 0.75],      # Przebicie odporności celu
                           [-10, -5, 0, 5, 10]]                 # Wartość utraconych HP rzucającego
ABILITYW_VALUES         = [[1, 1, 1, 1, 2],                     # Długość ukrycia rzucającego
                           [0, 0, 1, 1, 1]]                     # Ilość powtórzeń odpoczynku
ABILITYW_SUPER_VALUES   = [[1, 1, 1, 2, 2],                     # Długość ukrycia rzucającego
                           [1, 2, 2, 2, 2]]                     # Ilość powtórzeń odpoczynku
ABILITYE_VALUES         = [[0.1, 0.13, 0.15, 0.17, 0.2],        # Przelicznik MS rzucającego
                           [0, 0, 1, 1, 1]]                     # Ilość powtórzeń odpoczynku
ABILITYE_SUPER_VALUES   = [[0.15, 0.17, 0.2, 0.22, 0.25],       # Przelicznik MS rzucającego
                           [1, 1, 1, 2, 2]]                     # Ilość powtórzeń odpoczynku
ABILITYR_VALUES         = [[220, 170, 120],                     # Minimalna wartość MS zapewniająca udaną kradzież
                           [15, 10, 10],                        # Szansa na otrzymanie efektu dziurawa kieszeń (w procentach)
                           [3, 3, 2],                           # Długość dziurawej kieszeni rzucającego
                           [0.4, 0.6, 0.8],                     # Koszt nieudanej zdolności
                           [1, 1, 2],                           # Skrócenie czasu odnowienia zdolności
                           [1, 1, 2]]                           # Długość ukrycia rzucającego
PASSIVE_VALUES          = [[10, 15, 20],                        # Liczba Mana przywracana w ukrytym odpoczynku
                           [25, 28, 30]]                        # Liczba HP przywracana w ukrytym odpoczynku

def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    repeat = math.ceil(user.getMS() * ABILITYQ_VALUES[0][ability.getLevel()])
    dmg = user.getAD() * ABILITYQ_VALUES[1][ability.getLevel()]
    for i in range(repeat):
        user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYQ_VALUES[2][ability.getLevel()])
    user.changeStat(STAT_HP, ABILITYQ_VALUES[3][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    repeat = math.ceil(user.getMS() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()])
    dmg = user.getAD() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()]
    for i in range(repeat):
        user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYQ_SUPER_VALUES[2][ability.getLevel()])
    user.changeStat(STAT_HP, ABILITYQ_SUPER_VALUES[3][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.getEffectByKey(EFFECT_HIDE).changeCount(ABILITYW_VALUES[0][ability.getLevel()])
    for i in range(int(ABILITYW_VALUES[1][ability.getLevel()])):
        user.rest()

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.getEffectByKey(EFFECT_HIDE).changeCount(ABILITYW_SUPER_VALUES[0][ability.getLevel()])
    for i in range(int(ABILITYW_SUPER_VALUES[1][ability.getLevel()])):
        user.rest()

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    ms = user.getMS() * ABILITYE_VALUES[0][ability.getLevel()]
    user.changeStat(STAT_MS, value=ms)
    for i in range(int(ABILITYE_VALUES[1][ability.getLevel()])):
        user.rest()

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    ms = user.getMS() * ABILITYE_SUPER_VALUES[0][ability.getLevel()]
    user.changeStat(STAT_MS, value=ms)
    for i in range(int(ABILITYE_SUPER_VALUES[1][ability.getLevel()])):
        user.rest()

    user.abilityUsed(ability)

    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    print("Co chcesz ukraść (ID)? ", end='')
    itemID = stringToInt(input())
    item = user.playerShop.search(itemID)
    if item != None:
        if random.randint(0, 300) > ABILITYR_VALUES[0][ability.getLevel()] - user.getMS():
            user.shopChangeStatAfterBuy(item, goldUsed=False)
            print("Skradziono: " + item.getName())
            dmg = ABILITYR_VALUES[0][ability.getLevel()] - user.getMS()
            if dmg < 0:
                print("Udana kradzież")
            else:
                print("Kosztowało cię to: " + str(dmg) + " " + STAT_HP)
            if random.randint(0, 100) < ABILITYR_VALUES[1][ability.getLevel()]:
                print("Zachaczyłeś o gwóźdź przy półce")
                user.getEffectByKey(EFFECT_HOLE_POCKET).changeCount(ABILITYR_VALUES[2][ability.getLevel()])
            user.abilityUsed(ability)
        else:
            print("Nie udało Ci się tym razem")
            user.changeStat(STAT_MANA, -ability.getCurrCost() * ABILITYR_VALUES[3][ability.getLevel()])
            user.getEffectByKey(EFFECT_HIDE).changeCount(ABILITYR_VALUES[5][ability.getLevel()])
            ability.setCurrCD(ability.getDefCD() - ABILITYR_VALUES[4][ability.getLevel()])
            abilityCD_msg1(abilityName=ability.getName(), changeCD=ability.getCurrCD(), defaultCD=ability.getDefCD())
    else:
        print("Niepoprawny itemID")
        user.lobby()