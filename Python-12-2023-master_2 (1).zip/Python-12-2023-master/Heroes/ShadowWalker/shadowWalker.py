from Heroes.ShadowWalker.abilities import *

class ShadowWalker(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Mroczny Wędrowiec",
                         HP=150, MAXHP=150, HPREG=10,
                         Mana=50, MAXMana=50, ManaREG=5,
                         AD=25, AP=5, AR=5, MR=5,
                         AS=1.5, CRIT=5, MS=70, GOLD=600)

    def preparePlayer(self, id, players):
        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Szybki Bieg", cost=20, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Zasłona Ciemności", cost=25, cd=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Czyszczenie Obuwia", cost=25, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Zakupy Cienia", cost=60, cd=4, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Spoczynek w Cieniu", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Buty Walkera*", STAT_HP: 20, STAT_MAXHP: 20, STAT_MS: 60, STAT_GOLD: 1350}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Lekkość Pomykacza*", STAT_AR: -10, STAT_MR: -10, STAT_MS: 40, STAT_GOLD: 0}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Bujne Zarośla*", STAT_GOLD: 500}, {EFFECT_HIDE: 2}, autoGold=False)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityW(user=self, ability=ability)
            else:
                abilityW(user=self, ability=ability)
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityE(user=self, ability=ability)
            else:
                abilityE(user=self, ability=ability)
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            abilityR(user=self, ability=ability)
        else:
            self.lobby()

    def rest(self):
        if self.getEffectByKey(EFFECT_HIDE).isActive():
            hideEffect_msg1()
            self.changeStat(STAT_MANA, PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])
            self.changeStat(STAT_HP, PASSIVE_VALUES[1][self.getAbilityByIndex(9).getLevel()])
        super().rest()