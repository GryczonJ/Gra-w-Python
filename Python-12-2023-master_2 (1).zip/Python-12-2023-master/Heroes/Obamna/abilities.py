from BasicClasses.functions import *
from Heroes.Obamna.messages import *
from NeutralChampions.Appendage.appendage import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[40, 35, 30, 20, 15],            # Minimalny Crit do powodzenia kradzieży
                           [50, 40, 30, 20, 10],            # Szansa na wystąpienie krwawienia (w procentach)
                           [2, 2, 2, 2, 3],                 # Długość furii rzucającego
                           [1, 1, 1, 1, 2]]                 # Skrócenie czasu odnowienia zdolności
ABILITYQ_SUPER_VALUES   = [[100, 130, 160, 190, 250]]       # Stała wartość Gold
ABILITYW_VALUES         = [[0, 0.1, 0.2, 0.3, 0.4]]         # Wzmocnienie statystyk secretService
ABILITYW_SUPER_VALUES   = [[0.5, 0.7, 1, 1.2, 1.5]]         # Wzmocnienie statystyk secretService
ABILITYE_VALUES         = [[1, 1, 1, 1, 2]]                 # Długość ukrycia rzucającego
ABILITYE_SUPER_VALUES   = [[1, 1, 1, 2, 2]]                 # Długość ukrycia rzucającego
ABILITYR_VALUES         = [[0.7, 0.8, 0.9],                 # Przelicznik AP rzucającego
                           [10, 15, 20],                    # Bazowe obrażenia
                           [0.75, 0.7, 0.65],               # Przebicie odporności na magię
                           [65, 75, 85]]                    # Prawdopodobieństwo ogłuszenia (w procentach)
PASSIVE_VALUES          = [[50, 60, 80]]                    # Liczba Gold od każdego gracza

def abilityQ(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    print("Co chcesz ukraść (ID)? ", end='')
    itemID = stringToInt(input())
    item = user.playerShop.search(itemID)
    if item != None:
        if random.randint(0, ABILITYQ_VALUES[0][ability.getLevel()]) <= user.getCRIT():
            user.shopChangeStatAfterBuy(item, goldUsed=False)
            print("Skradziono: " + item.getName())
            print("Udana kradzież")
            if random.randint(0, 100) <= ABILITYQ_VALUES[1][ability.getLevel()]:
                user.getEffectByKey(EFFECT_BLEED).changeCount(2)
            user.abilityUsed(ability)
        else:
            user.getEffectByKey(EFFECT_STUN).changeCount(1)
            user.getEffectByKey(EFFECT_FURY).changeCount(ABILITYQ_VALUES[2][ability.getLevel()])
            print("Nie udało Ci się tym razem")
            user.changeStat(STAT_MANA, -ability.getCurrCost())
            ability.setCurrCD(ability.getDefCD() - ABILITYQ_VALUES[3][ability.getLevel()])
            abilityCD_msg1(abilityName=ability.getName(), changeCD=ability.getCurrCD(), defaultCD=ability.getDefCD())
    else:
        print("Niepoprawny itemID")
        user.lobby()

def superAbilityQ(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    print("Co chcesz ukraść (ID)? ", end='')
    itemID = stringToInt(input())
    item = user.playerShop.search(itemID)
    if item != None:
        user.shopChangeStatAfterBuy(item)
        print("Skradziono: " + item.getName())
        print("Udana kradzież")
        user.changeStat(STAT_GOLD, value=ABILITYQ_SUPER_VALUES[0][ability.getLevel()])

        user.abilityUsed(ability)
        user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)
    else:
        print("Niepoprawny itemID")
        user.lobby()

def abilityW(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    secretService = Appendage(Master=user, ID=len(user.getPlayers()), players=user.getPlayers(), Name="Secret Service",
                             HP=100, MAXHP=100, AD=15, AR=10, MR=10)
    secretService.appendageBuff(ABILITYW_VALUES[0][ability.getLevel()])
    tempPlayers = [secretService]
    selfSecretServiceList = [secretService]
    if user.secretServiceList != None and len(user.secretServiceList) > 0:
        selfSecretServiceList.extend(user.secretServiceList)
    user.secretServiceList = selfSecretServiceList
    tempPlayers.extend(user.getPlayers())
    for secretService in user.secretServiceList:
        secretService.setPlayers(tempPlayers.copy())
    for player in user.getPlayers():
        player.setPlayers(user.secretServiceList[0].getPlayers().copy())

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    secretService = Appendage(Master=user, ID=len(user.getPlayers()), players=user.getPlayers(), Name="Secret Service",
                              HP=100, MAXHP=100, AD=15, AR=10, MR=10)
    secretService.appendageBuff(ABILITYW_SUPER_VALUES[0][ability.getLevel()])
    tempPlayers = [secretService]
    selfSecretServiceList = [secretService]
    if user.secretServiceList != None and len(user.secretServiceList) > 0:
        selfSecretServiceList.extend(user.secretServiceList)
    user.secretServiceList = selfSecretServiceList
    tempPlayers.extend(user.getPlayers())
    for secretService in user.secretServiceList:
        secretService.setPlayers(tempPlayers.copy())
    for player in user.getPlayers():
        player.setPlayers(user.secretServiceList[0].getPlayers().copy())

    abilityW(user=user, ability=ability)

    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.getEffectByKey(EFFECT_HIDE).changeCount(ABILITYE_VALUES[0][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.getEffectByKey(EFFECT_HIDE).changeCount(ABILITYE_SUPER_VALUES[0][ability.getLevel()])

    tempAbility = user.getAbilityByIndex(6)
    currCost = tempAbility.getCurrCost()
    currCd = tempAbility.getCurrCD()
    abilityW(user=user, ability=tempAbility)
    user.changeStat(STAT_MANA, currCost)
    tempAbility.setCurrCD(currCd)

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero,target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYR_VALUES[0][ability.getLevel()] + ABILITYR_VALUES[1][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target, MRperc=ABILITYR_VALUES[2][ability.getLevel()])
    if random.randint(0, 100) <= ABILITYR_VALUES[3][ability.getLevel()]:
        target.getEffectByKey(EFFECT_STUN).changeCount(1)

    user.abilityUsed(ability)