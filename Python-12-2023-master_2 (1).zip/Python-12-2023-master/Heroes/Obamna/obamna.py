from Heroes.Obamna.abilities import *

class Obamna(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Obamna",
                         HP=200, MAXHP=200, HPREG=20,
                         Mana=60, MAXMana=60, ManaREG=10,
                         AD=20, AP=15, AR=5, MR=5,
                         AS=1, CRIT=0, MS=60, GOLD=900)

    def preparePlayer(self, id, player):

        super().preparePlayer(id, player)

        # SpellQ
        ability = Ability(name="Czarne Korzenie", cost=30, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Secret Service", cost=40, cd=4, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Ucieczka w Schron", cost=30, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Taktyczny Paralizator", cost=25, cd=3, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        #Passive
        ability = Ability(name="Podatki", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.secretServiceList = None

        self.playerShop.addItem({STAT_NAME: "Obama Care*", STAT_MAXHP: 30, STAT_HP: 20, STAT_AP: 15,
                                 STAT_AR: 10, STAT_MR: 10, STAT_MS: 20, STAT_GOLD: 1500}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Białe Przebranie*", STAT_AR: 15, STAT_AP: 20, STAT_GOLD: 1000}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Zbiorowy Strajk*", STAT_AR: 20, STAT_MR: 20, STAT_MS: 30, STAT_GOLD: 1300}, autoGold=False)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityQ(user=self, ability=ability)
            else:
                abilityQ(user=self, ability=ability)
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityW(user=self, ability=ability)
            else:
                abilityW(user=self, ability=ability)
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityE(user=self, ability=ability)
            else:
                abilityE(user=self, ability=ability)
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                abilityR(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def changeStat(self, key, value, blockMsg = False, blockStatLimit = False):
        if key == "HP" and value < 0 and self.secretServiceList != None and len(self.secretServiceList) > 0:
            for secretService in self.secretServiceList:
                if secretService.getEffectByKey(EFFECT_DEFENSE_OF_MR).isActive():
                    secretService.changeStat(key, value)
                    return
            super().changeStat(key, value)
        else:
            super().changeStat(key, value)
            
    def endTurn(self):
        print("Efekt podatków:")
        self.changeStat("GOLD", len(self.getPlayers()) * PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])
        super().endTurn()
