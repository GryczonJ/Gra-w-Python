from Heroes.Rayman.abilities import *

class Rayman(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Promienisty",
                         HP=225, MAXHP=225, HPREG=10,
                         Mana=80, MAXMana=80, ManaREG=8,
                         AD=20, AP=10, AR=15, MR=15,
                         AS=1.2, CRIT=2, MS=40, GOLD=600)

    def preparePlayer(self, id, players):
        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Seria pięściami", cost=20, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Czerwona Puszka", cost=35, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Niebieska Puszka", cost=25, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Potęga Leptysa", cost=30, cd=2, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Ładowana Pięść", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Sok Śliwkowy*", STAT_HP: 40, STAT_MAXHP: 40, STAT_AD: 25, STAT_MS: 30, STAT_GOLD: 1700}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Pomarańczowa puszka*", STAT_AD: 40, STAT_AP: 20, STAT_CRIT: 4, STAT_AR: 10, STAT_GOLD: 1700}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Zużyte puszki*", STAT_AR: 20, STAT_MR: 15, STAT_MS: -10, STAT_AD: 10, STAT_GOLD: 1100}, autoGold=False)

    def getCritDMG(self) -> float:
        return super().getCritDMG() + PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()]

    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityW(user=self, ability=ability)
            else:
                abilityW(user=self, ability=ability)
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityE(user=self, target=target, ability=ability)
                else:
                    abilityE(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            abilityR(user=self, ability=ability)
        else:
            self.lobby()