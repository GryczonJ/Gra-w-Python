from BasicClasses.functions import *
from Heroes.ChoGath.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.3, 0.35, 0.4, 0.45, 0.5],     # Przelicznik AD rzucającego
                           [0.05, 0.1, 0.15, 0.2, 0.25],    # Przelicznik MS rzucającego
                           [3, 3, 3, 4, 4],                 # Ilość powtórzeń ataku
                           [0.85, 0.82, 0.8, 0.79, 0.78]]   # Przebicie odporności
ABILITYQ_SUPER_VALUES   = [[0.35, 0.4, 0.45, 0.5, 0.55],    # Przelicznik AD rzucającego
                           [0.1, 0.12, 0.2, 0.25, 0.3],     # Przelicznik MS rzucającego
                           [4, 4, 5, 5, 6],                 # Ilość powtórzeń ataku
                           [0.83, 0.80, 0.78, 0.75, 0.7]]   # Przebicie odporności
ABILITYW_VALUES         = [[0.1, 0.12, 0.14, 0.16, 0.18],   # Przelicznik AD rzucającego
                           [10, 11, 13, 15, 18],            # Otrzymana wartość AR
                           [-5, -2, 0, 2, 5],               # Utracona wartość MS
                           [1, 2, 2, 2, 2]]                 # Długość furii rzucającego
ABILITYW_SUPER_VALUES   = [[0.12, 0.14, 0.16, 0.18, 0.2],   # Przelicznik AD rzucającego
                           [12, 14, 16, 19, 22],            # Otrzymana wartość AR
                           [12, 14, 16, 19, 22],            # Otrzymana wartość MR
                           [0, 3, 5, 8, 13],                # Utracona wartość MS
                           [2, 2, 2, 2, 3]]                 # Długość furii rzucającego
ABILITYE_VALUES         = [[0.45, 0.55, 0.6, 0.65, 0.7],    # Przelicznik AP atakującego
                           [0.05, 0.1, 0.15, 0.2, 0.25],    # Przelicznik MR celu
                           [0.7, 0.68, 0.66, 0.64, 0.62],   # Przebicie odporności na magię
                           [1, 1, 1, 1, 2]]                 # Długość ogłuszenia celu
ABILITYE_SUPER_VALUES   = [[0.65, 0.7, 0.72, 0.73, 0.75],   # Przelicznik AP atakującego
                           [0.15, 0.17, 0.19, 0.21, 0.23],  # Przelicznik MR celu
                           [0.7, 0.65, 0.6, 0.55, 0.5],     # Przebicie odporności na magię
                           [1, 1, 1, 2, 2]]                 # Długość ogłuszenia celu
ABILITYR_VALUES         = [[200, 250, 300]]                 # Ilość przywróconego HP
PASSIVE_VALUES          = [[0.2, 0.3, 0.5]]                 # Dodatkowe obrażenia od trafień krytycznych

def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYQ_VALUES[0][ability.getLevel()] + user.getMS() * ABILITYQ_VALUES[1][ability.getLevel()]
    for i in range(int(ABILITYQ_VALUES[2][ability.getLevel()])):
        user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYQ_VALUES[3][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()] + user.getMS() * ABILITYQ_SUPER_VALUES[1][ability.getLevel()]
    for i in range(int(ABILITYQ_SUPER_VALUES[2][ability.getLevel()])):
        user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYQ_SUPER_VALUES[3][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    ad = user.getAD() * ABILITYW_VALUES[0][ability.getLevel()]
    user.changeStat(STAT_AD, value=ad)
    user.changeStat(STAT_AR, value=ABILITYW_VALUES[1][ability.getLevel()])
    user.changeStat(STAT_MS, value=ABILITYW_VALUES[2][ability.getLevel()])
    user.getEffectByKey(EFFECT_FURY).changeCount(int(ABILITYW_VALUES[3][ability.getLevel()]))

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    ad = user.getAD() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    user.changeStat(STAT_AD, value=ad)
    user.changeStat(STAT_AR, value=ABILITYW_SUPER_VALUES[1][ability.getLevel()])
    user.changeStat(STAT_MR, value=ABILITYW_SUPER_VALUES[2][ability.getLevel()])
    user.changeStat(STAT_MS, value=ABILITYW_SUPER_VALUES[3][ability.getLevel()])
    user.getEffectByKey(EFFECT_FURY).changeCount(int(ABILITYW_SUPER_VALUES[4][ability.getLevel()]))

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYE_VALUES[0][ability.getLevel()] + target.getMR() * ABILITYE_VALUES[1][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target, MRperc=ABILITYE_VALUES[2][ability.getLevel()])
    target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYE_VALUES[3][ability.getLevel()]))

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYE_SUPER_VALUES[0][ability.getLevel()] + target.getMR() * ABILITYE_SUPER_VALUES[1][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target, MRperc=ABILITYE_SUPER_VALUES[2][ability.getLevel()])
    target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYE_SUPER_VALUES[3][ability.getLevel()]))

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    user.changeStat(STAT_HP, value=ABILITYR_VALUES[ABILITYR_VALUES[0][ability.getLevel()]])

    user.abilityUsed(ability)