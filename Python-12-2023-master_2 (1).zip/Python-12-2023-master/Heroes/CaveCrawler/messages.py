def ability_msg1(playerName: str, abilityName: str):
    print(playerName + " użył zdolności: " + abilityName)

def superAbility_msg1(playerName: str, abilityName: str):
    print(playerName + " użył wzmocnionej zdolności: " + abilityName)
    
def stacks_msg1(changeStack: int):
    print("Liczba ładunków wzrosła o: " + str(changeStack))
    
def abilityCost_msg1(abilityName: str, changeCost: int, costType: str, defaultCost: int):
    print("Koszt zdolności " + abilityName + " wzrósł o: " + str(changeCost) + " " + costType + 
          " (aktualny: " + str(defaultCost) + " " + costType + ")")

def powerfullAbility(playerName: str, abilityName: str):
    print(playerName + " użył potężnej zdolności: " + abilityName)

def abilityR_msg1(repeat: int):
    print("Farma została wywołana " + str(repeat) + " razy")