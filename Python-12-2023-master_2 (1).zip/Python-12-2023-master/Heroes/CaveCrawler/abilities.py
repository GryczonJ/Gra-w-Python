from BasicClasses.functions import *
from Heroes.CaveCrawler.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[5, 5, 6, 6, 7],                 # Mnożnik ładunków
                           [40, 42, 44, 46, 48],            # Stała wartość złota
                           [1, 1, 1, 1, 2]]                 # Liczba zyskanych ładunków
ABILITYQ_SUPER_VALUES   = [[8, 8, 9, 9, 10],                # Mnożnik ładunków
                           [70, 72, 74, 76, 78],            # Stała wartość złota
                           [1, 1, 1, 2, 2]]                 # Liczba zyskanych ładunków
ABILITYW_VALUES         = [[0.2, 0.21, 0.22, 0.23, 0.25],   # Mnożnik AD rzucającego
                           [1, 2, 2, 2, 2],                 # Długość furii rzucającego
                           [0.25, 0.24, 0.23, 0.22, 0.2]]   # Przelicznik AD do zwiększenia kosztu umiejętności
ABILITYW_SUPER_VALUES   = [[0.3, 0.31, 0.32, 0.33, 0.35],   # Mnożnik AD rzucającego
                           [2, 2, 2, 2, 3],                 # Długość furii rzucającego
                           [0.25, 0.24, 0.23, 0.22, 0.2]]   # Przelicznik AD do zwiększenia kosztu umiejętności
ABILITYE_VALUES         = [[1, 1, 2, 2, 3]]                 # Długość obnażenia celu
ABILITYE_SUPER_VALUES   = [[2, 2, 2, 3, 3],                 # Długość obnażenia celu
                           [1, 2, 2, 2, 3]]                 # Długość furii rzucającego
ABILITYR_VALUES         = [[5, 5, 4],                       # Liczba staków, przyznająca dodatkową farmę
                           [2, 2, 3],                       # Stała wartość farmy
                           [1, 1, 2]]                       # Długość ukrycia rzucającego
PASSIVE_VALUES          = [[30, 40, 50]]                    # Szansa na ogłuszenie celu

def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    goldDrain = user.getStacks() * ABILITYQ_VALUES[0][ability.getLevel()] + ABILITYQ_VALUES[1][ability.getLevel()]
    statDrain(fromTarget=target, toTarget=user, key=STAT_GOLD, value=goldDrain)

    ability.changeDefCost(1)
    user.abilityUsed(ability)
    user.changeStacks(ABILITYQ_VALUES[2][ability.getLevel()])
    stacks_msg1(changeStack=ABILITYQ_VALUES[2][ability.getLevel()])
    abilityCost_msg1(abilityName=ability.getName(), changeCost=1,
                     costType=ability.getCostType(), defaultCost=ability.getDefCost())

def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    goldDrain = user.getStacks() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()] + ABILITYQ_SUPER_VALUES[1][ability.getLevel()]
    statDrain(fromTarget=target, toTarget=user, key=STAT_GOLD, value=goldDrain)

    ability.changeDefCost(1)
    user.abilityUsed(ability)
    user.changeStacks(ABILITYQ_SUPER_VALUES[2][ability.getLevel()])
    stacks_msg1(changeStack=ABILITYQ_SUPER_VALUES[2][ability.getLevel()])
    abilityCost_msg1(abilityName=ability.getName(), changeCost=1,
                     costType=ability.getCostType(), defaultCost=ability.getDefCost())
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    additionalAD = user.getAD() * ABILITYW_VALUES[0][ability.getLevel()]
    user.changeStat(key=STAT_AD, value=additionalAD)
    user.getEffectByKey(key=EFFECT_FURY).changeCount(int(ABILITYW_VALUES[1][ability.getLevel()]))

    changeCost = math.floor(user.getAD() * ABILITYW_VALUES[2][ability.getLevel()])
    ability.changeDefCost(changeCost)
    user.abilityUsed(ability)
    abilityCost_msg1(abilityName=ability.getName(), changeCost=changeCost,
                     costType=ability.getCostType(), defaultCost=ability.getDefCost())

def superAbilityW(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    additionalAD = user.getAD() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    user.changeStat(key=STAT_AD, value=additionalAD)
    user.getEffectByKey(key=EFFECT_FURY).changeCount(int(ABILITYW_SUPER_VALUES[1][ability.getLevel()]))

    changeCost = math.floor(user.getAD() * ABILITYW_SUPER_VALUES[2][ability.getLevel()])
    ability.changeDefCost(changeCost)
    user.abilityUsed(ability)
    abilityCost_msg1(abilityName=ability.getName(), changeCost=changeCost,
                     costType=ability.getCostType(), defaultCost=ability.getDefCost())
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    target.getEffectByKey(key=EFFECT_PERC_DISARM).changeCount(ABILITYE_VALUES[0][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    target.getEffectByKey(key=EFFECT_PERC_DISARM).changeCount(ABILITYE_SUPER_VALUES[0][ability.getLevel()])
    user.getEffectByKey(key=EFFECT_FURY).changeCount(ABILITYE_SUPER_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    repeat = math.floor(user.getStacks() / ABILITYR_VALUES[0][ability.getLevel()]) + ABILITYR_VALUES[1][ability.getLevel()]
    abilityR_msg1(repeat=repeat)
    for i in range(repeat):
        user.farm()
    user.getEffectByKey(key=EFFECT_HIDE).changeCount(ABILITYR_VALUES[2][ability.getLevel()])

    user.abilityUsed(ability)