from BasicClasses.heroPattern import HeroPattern
from Heroes.CaveCrawler.abilities import *

class CaveCrawler(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Grotołaz",
                         HP=200, MAXHP=200, HPREG=10,
                         Mana=60, MAXMana=60, ManaREG=10,
                         AD=25, AP=0, AR=15, MR=15,
                         AS=0.8, CRIT=0, MS=30, GOLD=753)

    def preparePlayer(self, id, players):

        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Pogarda dla Słabych", cost=20, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)

        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Znak Grotołaza", cost=25, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Grotołaz Rozpruwacz", cost=30, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Sześćdziesiona", cost=80, cd=4, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Zamach Kilofem", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Krakowska maczeta*", STAT_AD: 75, STAT_CRIT: 10, STAT_GOLD: 2100}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Wyposażenie górnika*", STAT_AR: 15, STAT_MR: 15, STAT_MS: 20, STAT_GOLD: 1200}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Klucznik*", STAT_GOLD: 900}, {EFFECT_LUCK: 2}, autoGold=False)

        self.setStacks(0)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityW(user=self, ability=ability)
            else:
                abilityW(user=self, ability=ability)
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityE(user=self, target=target, ability=ability)
                else:
                    abilityE(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            abilityR(user=self, ability=ability)
        else:
            self.lobby()

    def getADDMG(self, dmg: float | int, target: HeroPattern, ARperc: int | float = 1.0, CRITLuck: int = 0):
        super().getADDMG(dmg, target, ARperc, CRITLuck)
        if random.randint(0, 100) <= PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()]:
            target.getEffectByKey(EFFECT_STUN).changeCount(1)


