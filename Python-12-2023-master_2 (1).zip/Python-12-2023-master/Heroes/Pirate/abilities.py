from BasicClasses.functions import *
from Heroes.Pirate.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[120, 100, 80, 60, 40]]          # MS gwarantujący farmę
ABILITYQ_SUPER_VALUES   = [[120, 100, 80, 60, 40]]          # MS gwarantujący farmę
ABILITYW_VALUES         = [[0.12, 0.15, 0.17, 0.20, 0.23],  # Przelicznik Mana celu
                           [0.4, 0.45, 0.47, 0.5, 0.55]]    # Przelicznik MS rzucającego
ABILITYW_SUPER_VALUES   = [[0.18, 0.22, 0.25, 0.27, 0.3],   # Przelicznik Mana celu
                           [0.6, 0.7, 0.75, 0.8, 0.85]]     # Przelicznik MS rzucającego
ABILITYE_VALUES         = [[1, 1, 1, 1, 1],                 # Powtórzenia odpoczynku
                           [1, 1, 1, 1, 2]]                 # Długość ukrycia rzucającego
ABILITYE_SUPER_VALUES   = [[1, 1, 1, 1, 1],                 # Powtórzenia odpoczynku
                           [2, 2, 2, 2, 2],                 # Długość ukrycia rzucającego
                           [150, 160, 190, 210, 230]]       # Stała wartość złota
ABILITYR_VALUES         = [[0.002, 0.003, 0.005],           # Przelicznik sumaryczny MAXHP i MS rzucającego
                           [0.03, 0.05, 0.07]]              # Przelicznik GOLD rzucającego
PASSIVE_VALUES          = {STAT_AD: [1, 2, 3],             # Skarb: obrażenia od ataku
                           STAT_MS: [1, 2, 3],             # Skarb: prędkość ruchu
                           STAT_AS: [0.01, 0.02, 0.03],    # Skarb: prędkość ataku
                           STAT_GOLD: [20, 30, 40]}        # Skarb: złoto

def abilityQ(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    if random.randint(0, ABILITYQ_VALUES[0][ability.getLevel()]) < user.getMS():
        user.farm()
    else:
        user.rest()
    user.rest()

    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.farm()
    if random.randint(0, ABILITYQ_SUPER_VALUES[0][ability.getLevel()]) < user.getMS():
        user.farm()
    else:
        user.rest()
    user.rest()

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    mana = user.getMana() * ABILITYW_VALUES[0][ability.getLevel()]
    statDrain(fromTarget=target, toTarget=user, key=STAT_MANA, value=mana)
    gold = user.getMS() * ABILITYW_VALUES[1][ability.getLevel()]
    statDrain(fromTarget=target, toTarget=user, key=STAT_GOLD, value=gold)

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    mana = user.getMana() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    statDrain(fromTarget=target, toTarget=user, key=STAT_MANA, value=mana)
    gold = user.getMS() * ABILITYW_SUPER_VALUES[1][ability.getLevel()]
    statDrain(fromTarget=target, toTarget=user, key=STAT_GOLD, value=gold)

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    for i in range(int(ABILITYE_VALUES[0][ability.getLevel()])):
        user.rest()
    user.getEffectByKey(EFFECT_HIDE).changeCount(int(ABILITYE_VALUES[1][ability.getLevel()]))

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    for i in range(int(ABILITYE_SUPER_VALUES[0][ability.getLevel()])):
        user.rest()
    user.getEffectByKey(EFFECT_HIDE).changeCount(int(ABILITYE_SUPER_VALUES[1][ability.getLevel()]))
    user.changeStat(STAT_GOLD, value=ABILITYE_SUPER_VALUES[2][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getMAXHP() * user.getMS() * ABILITYR_VALUES[0][ability.getLevel()]
    dmg += user.getGOLD() * ABILITYR_VALUES[1][ability.getLevel()]
    user.getTrueDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)