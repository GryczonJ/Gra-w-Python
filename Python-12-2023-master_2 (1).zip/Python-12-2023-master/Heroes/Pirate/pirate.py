from Heroes.Pirate.abilities import *

class Pirate(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Jednooki",
                         HP=225, MAXHP=225, HPREG=15,
                         Mana=30, MAXMana=60, ManaREG=8,
                         AD=35, AP=5, AR=15, MR=5,
                         AS=1.12, CRIT=0, MS=50, GOLD=600)

    def preparePlayer(self, id, players):
        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Cumujemy", cost=15, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Abordaż", cost=30, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Zejście pod pokład", cost=30, cd=5, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Przeciągnięcie pod kilem", cost=80, cd=5, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Krzyżyk oznacza skarb", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Przeklęta Szabla*", STAT_AD: 25, STAT_CRIT: 10, STAT_GOLD: 900}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Stalowa Noga*", STAT_AR: 5, STAT_MR: 5, STAT_MS: -5, STAT_GOLD: 100}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Żagle Potępionych*", STAT_MS: 50, STAT_GOLD: 900}, autoGold=False)

        self.setStacks(0)
        self.PRESTACKS = 0
        self.targetAction = "NULL"

    def setTarget(self):
        if self.targetAction == "NULL":
            possibilities = []
            for ability in self.getAbilities():
                if not ability.isPassive() and self.checkAbility(ability, False):
                    possibilities.append(ability.getName())
            index = random.randint(0, len(possibilities) - 1)
            self.targetAction = possibilities[index]
            self.PRESTACKS = self.getStacks()

    def startTurn(self):
        self.setTarget()
        if self.getEffectByKey(EFFECT_STUN).isActive() or self.getEffectByKey(EFFECT_PANTHEON_FLIGHT).isActive()\
                or self.getEffectByKey(EFFECT_EXHAUSTION).isActive():
            self.PRESTACKS -= 1
        super().startTurn()

    def preLobby(self):
        if self.targetAction != "":
            print("Twoim celem jest: " + self.targetAction)

    def postLobby(self, action):
        try:
            index = action - 1
            actionName = self.getAbilityByIndex(index).getName()
            if actionName == self.targetAction:
                self.targetAction = ""
                index = random.randint(0, len(PASSIVE_VALUES) - 1)
                key = list(PASSIVE_VALUES)[index]
                value = PASSIVE_VALUES[key][self.getAbilityByIndex(9).getLevel()] + (0.5 * self.getStacks() * PASSIVE_VALUES[key][self.getAbilityByIndex(9).getLevel()])
                self.changeStat(key, value)
                rarityDrop(4, value, key)
                self.changeStacks(1)
        except:
            print("", end='')

    def spellQ(self, ability):
        if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
            superAbilityQ(user=self, ability=ability)
        else:
            abilityQ(user=self, ability=ability)

    def spellW(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityW(user=self, target=target, ability=ability)
                else:
                    abilityW(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityE(user=self, ability=ability)
            else:
                abilityE(user=self, ability=ability)
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                abilityR(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def endTurn(self):
        if self.getStacks() == self.PRESTACKS:
            lostStacks(self.getName(), self.getStacks())
            self.setStacks(0)
        super().endTurn()
        self.targetAction = "NULL"