from BasicClasses.functions import *
from Heroes.Floyd.messages import *
from NeutralChampions.Appendage.appendage import Appendage

##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.7, 0.75, 0.8, 0.9, 0.92],     # Przelicznik AD rzucającego
                           [0.15, 0.2, 0.25, 0.27, 0.3],    # Przelicznik MS rzucającego
                           [0.9, 0.85, 0.8, 0.78, 0.75],    # Przebicie odporności
                           [2, 2, 2, 2, 2]]                 # Długość krwawienia celu
ABILITYQ_SUPER_VALUES   = [[0.8, 0.9, 1, 1.1, 1.15],        # Przelicznik AD rzucającego
                           [0.25, 0.3, 0.32, 0.35, 0.4],    # Przelicznik MS rzucającego
                           [0.85, 0.8, 0.75, 0.7, 0.67],    # Przebicie odporności
                           [2, 2, 2, 2, 2]]                 # Długość krwawienia celu
ABILITYW_VALUES         = [[0.1, 0.12, 0.15, 0.17, 0.2],    # Przelicznik AD rzaucającego
                           [1, 1, 1, 2, 2]]                 # Długość ogłuszenia celu
ABILITYW_SUPER_VALUES   = [[0.2, 0.22, 0.25, 0.3, 0.33],    # Przelicznik AD rzucającego
                           [1, 1, 2, 2, 2]]                 # Długość ogłuszenia celu
ABILITYE_VALUES         = [[0, 0.1, 0.2, 0.3, 0.4]]         # Wzmocnienie statystyk officerDerec
ABILITYE_SUPER_VALUES   = [[0.5, 0.7, 1, 1.2, 1.5]]         # Wzmocnienie statystyk officerDerec
ABILITYR_VALUES         = [[0.75, 0.85, 0.9],               # Przelicznik AD rzucającego
                           [0.1, 0.14, 0.18],               # Przelicznik HP rzucającego
                           [0.9, 0.8, 0.7],                 # Przebicie odporności
                           [0.05, 0.08, 0.1],               # Procent zyskanego pancerza
                           [2, 2, 1]]                       # Długość wyczerpania rzucającego
PASSIVE_VALUES          = [[1, 1, 2]]                       # Długość furii po byciu celem

def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYQ_VALUES[0][ability.getLevel()] + user.getMS() * ABILITYQ_VALUES[1][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYQ_VALUES[2][ability.getLevel()])
    target.getEffectByKey(EFFECT_BLEED).changeCount(int(ABILITYQ_VALUES[3][ability.getLevel()]))


    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()] + user.getMS() * ABILITYQ_SUPER_VALUES[1][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYQ_SUPER_VALUES[2][ability.getLevel()])
    target.getEffectByKey(EFFECT_BLEED).changeCount(ABILITYQ_SUPER_VALUES[3][ability.getLevel()])


    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_VALUES[0][ability.getLevel()]
    user.getTrueDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYW_VALUES[1][ability.getLevel()]))

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    user.getTrueDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYW_SUPER_VALUES[1][ability.getLevel()]))


    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    officerDerec = Appendage(Master=user, ID=len(user.getPlayers()), players=user.getPlayers(), Name="Officer Derek",
                             HP=80, MAXHP=80, AD=25, AR=8, MR=8)
    officerDerec.appendageBuff(ABILITYE_VALUES[0][ability.getLevel()])
    tempPlayers = [officerDerec]
    selfOfficerDerecList = [officerDerec]
    if user.officerDerecList != None and len(user.officerDerecList) > 0:
        selfOfficerDerecList.extend(user.officerDerecList)
    user.officerDerecList = selfOfficerDerecList
    tempPlayers.extend(user.getPlayers())
    for secretService in user.officerDerecList:
        secretService.setPlayers(tempPlayers.copy())
    for player in user.getPlayers():
        player.setPlayers(user.officerDerecList[0].getPlayers().copy())

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    officerDerec = Appendage(Master=user, ID=len(user.getPlayers()), players=user.getPlayers(), Name="Officer Derek",
                                HP=80, MAXHP=80, AD=25, AR=8, MR=8)
    officerDerec.appendageBuff(ABILITYE_SUPER_VALUES[0][ability.getLevel()])
    tempPlayers = [officerDerec]
    selfOfficerDerecList = [officerDerec]
    if user.officerDerecList != None and len(user.officerDerecList) > 0:
        selfOfficerDerecList.extend(user.officerDerecList)
    user.officerDerecList = selfOfficerDerecList
    tempPlayers.extend(user.getPlayers())
    for secretService in user.officerDerecList:
        secretService.setPlayers(tempPlayers.copy())
    for player in user.getPlayers():
        player.setPlayers(user.officerDerecList[0].getPlayers().copy())

    abilityE(user=user, ability=ability)

    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYR_VALUES[0][ability.getLevel()] + user.getHP() * ABILITYR_VALUES[1][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYR_VALUES[2][ability.getLevel()])
    ar = dmg * ABILITYR_VALUES[3][ability.getLevel()]
    user.changeStat(key=STAT_AR, value=ar)
    user.getEffectByKey(EFFECT_EXHAUSTION).changeCount(int(ABILITYR_VALUES[4][ability.getLevel()]))

    user.abilityUsed(ability)