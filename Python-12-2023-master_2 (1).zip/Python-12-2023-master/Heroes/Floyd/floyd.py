from Heroes.Floyd.abilities import *
class Floyd(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Grzesiu Floryda",
                         HP=250, MAXHP=250, HPREG=10,
                         Mana=70, MAXMana=70, ManaREG=10,
                         AD=25, AP=15, AR=12, MR=10,
                         AS=1, CRIT=0, MS=45, GOLD=600)

    def preparePlayer(self, id, players):

        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Przykuc Kolanem", cost=50, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Nie mogę oddychać!", cost=75, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Wezwanie Dereka", cost=80, cd=4, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Black Lives Matter", cost=90, cd=7, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Triggered Nigga", maxLevel=3, passive=True)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.officerDerecList = None

        self.playerShop.addItem({STAT_NAME: "Tlen w Puszce*", STAT_HP: 45, STAT_MAXHP: 30, STAT_AR: 5, STAT_MR: 5, STAT_GOLD: 950}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Duży Czarny Konar*", STAT_AD: 30, STAT_AP: 20, STAT_CRIT: 4, STAT_MS: -5, STAT_GOLD: 1100}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Gumowa Pałka*", STAT_AP: 30, STAT_AR: 15, STAT_MR: 15, STAT_HPREG: 5, STAT_GOLD: 1800}, autoGold=False)


    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityW(user=self, target=target, ability=ability)
                else:
                    abilityW(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellE(self, ability: Ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityE(user=self, ability=ability)
            else:
                abilityE(user=self, ability=ability)
        else:
            self.lobby()

    def spellR(self, ability: Ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                abilityR(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def changeStat(self, key, value, blockMsg = False, blockStatLimit = False):
        if key == "HP" and value < 0 and self.officerDerecList != None and len(self.officerDerecList) > 0:
            for secretService in self.officerDerecList:
                if secretService.getEffectByKey(EFFECT_DEFENSE_OF_MR).isActive():
                    secretService.changeStat(key, value)
                    return
            super().changeStat(key, value)
        else:
            super().changeStat(key, value)

    def getLocated(self):
        print("Wiadomość od " + self.getName() + ": Teraz to mnie rozsierdziłeś")
        self.getEffectByKey(EFFECT_FURY).changeCount(1)