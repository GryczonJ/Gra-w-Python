def ability_msg1(playerName: str, abilityName: str):
    print(playerName + " użył zdolności: " + abilityName)

def superAbility_msg1(playerName: str, abilityName: str):
    print(playerName + " użył wzmocnionej zdolności: " + abilityName)

def powerfullAbility(playerName: str, abilityName: str):
    print(playerName + " użył potężnej zdolności: " + abilityName)