from BasicClasses.functions import *
from Heroes.Heavy.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[10, 13, 16, 19, 25]]    # Liczba uzyskanych AD
ABILITYQ_SUPER_VALUES   = [[20, 24, 25, 26, 30]]    # Liczba uzyskanych AD
ABILITYW_VALUES         = [[11, 12, 13, 14, 15],    # Liczba uzyskanych AR
                           [11, 12, 13, 14, 15]]    # Liczba uzyskanych MR
ABILITYW_SUPER_VALUES   = [[16, 17, 18, 19, 21],    # Liczba uzyskanych AR
                           [16, 17, 18, 19, 21]]    # Liczba uzyskanych MR
ABILITYE_VALUES         = [[1, 2, 2, 2, 2]]         # Długość zatrucia pozostałych
ABILITYE_SUPER_VALUES   = [[1, 2, 2, 2, 3],         # Długość zatrucia pozostałych
                           [1, 2, 2, 2, 3]]         # Długość krwawienia pozostałych
ABILITYR_VALUES         = [[0.10, 0.15, 0.17],      # Przelicznik MAXHP rzucającego
                           [0.20, 0.25, 0.28],      # Przelicznik MS rzucającego
                           [50, 60, 70],            # Szansa na ogłuszenie (w procentach)
                           [1, 1, 2],               # Długość ogłuszenia celu
                           [1, 1, 1]]               # Długość wyczerpania rzucającego
PASSIVE_VALUES          = [[1.9, 2.2, 2.5],         # Dodatkowy bonus do HP i Many ze wszystkich źródeł
                           [0.65, 0.75, 0.85]]      # Osłabienie do AP i AD ze wszystkich źródeł

def abilityQ(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.changeStat(STAT_AD, value=ABILITYQ_VALUES[0][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.changeStat(STAT_AD, value=ABILITYQ_SUPER_VALUES[0][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.changeStat(STAT_AR, value=ABILITYW_VALUES[0][ability.getLevel()])
    user.changeStat(STAT_MR, value=ABILITYW_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.changeStat(STAT_AR, value=ABILITYW_SUPER_VALUES[0][ability.getLevel()])
    user.changeStat(STAT_MR, value=ABILITYW_SUPER_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    for target in user.getPlayers():
        if target != user:
            target.getEffectByKey(EFFECT_POISON).changeCount(ABILITYE_VALUES[0][ability.getLevel()])


    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    for target in user.getPlayers():
        if target != user:
            target.getEffectByKey(EFFECT_POISON).changeCount(ABILITYE_SUPER_VALUES[0][ability.getLevel()])
            target.getEffectByKey(EFFECT_BLEED).changeCount(ABILITYE_SUPER_VALUES[1][ability.getLevel()])


    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getMAXHP() * ABILITYR_VALUES[0][ability.getLevel()] + user.getMS() * ABILITYR_VALUES[1][ability.getLevel()]
    user.getTrueDMG(dmg=dmg, target=target)
    if random.randint(0, 100) < ABILITYR_VALUES[2][ability.getLevel()]:
        target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYR_VALUES[3][ability.getLevel()]))
    user.getEffectByKey(EFFECT_EXHAUSTION).changeCount(int(ABILITYR_VALUES[4][ability.getLevel()]))


    user.abilityUsed(ability)