from Heroes.Heavy.abilities import *

class Heavy(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Gruby",
                         HP=270, MAXHP=270, HPREG=15,
                         Mana=50, MAXMana=50, ManaREG=8,
                         AD=15, AP=15, AR=50, MR=50,
                         AS=1, CRIT=0, MS=20, GOLD=600)


    def preparePlayer(self, id, players):

        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Gruba Moc", cost=30, cd=3, costType=STAT_HP, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Magiczny Pancerz", cost=60, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Tytanowy Pierd", cost=30, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Smagnięcie Brzucholem", cost=40, cd=4, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Intuicja Pasibrzucha", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Zbroja Tłuszczowa*", STAT_MAXHP: 100, STAT_HP: 60, STAT_AR: 25,
                                 STAT_MR: 25, STAT_MS: -25, STAT_GOLD: 2500}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Pancerne Skórzaki*", STAT_MS: 25, STAT_AD: 15, STAT_AR: 10,
                                 STAT_GOLD: 950}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Beczka Obfitości*", STAT_HP: 30, STAT_AR: 20, STAT_MR: 20,
                                 STAT_GOLD: 1400}, autoGold=False)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityQ(user=self, ability=ability)
            else:
                abilityQ(user=self, ability=ability)
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityW(user=self, ability=ability)
            else:
                abilityW(user=self, ability=ability)
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityE(user=self, ability=ability)
            else:
                abilityE(user=self, ability=ability)
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                abilityR(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def changeStat(self, key, value, blockMsg = False, blockStatLimit = False):
        if (key == "HP" or key == "Mana") and value > 0:
            return super().changeStat(key, value * PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()], blockMsg, blockStatLimit)
        elif (key == "AD" or key == "AP") and value > 0:
            return super().changeStat(key, value * PASSIVE_VALUES[1][self.getAbilityByIndex(9).getLevel()], blockMsg, blockStatLimit)
        else:
            return super().changeStat(key, value, blockMsg, blockStatLimit)
        
