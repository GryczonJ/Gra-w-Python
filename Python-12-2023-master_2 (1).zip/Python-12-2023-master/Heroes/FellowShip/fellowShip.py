from BasicClasses.Shop.item import Item
from BasicClasses.heroPattern import HeroPattern
from Heroes.FellowShip.abilities import *

class FellowShip(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Drużyna Pierścienia",
                         HP=225, MAXHP=225, HPREG=12,
                         Mana=50, MAXMana=70, ManaREG=10,
                         AD=20, AP=20, AR=10, MR=10,
                         AS=1.2, CRIT=5, MS=60, GOLD=570)

    def preparePlayer(self, id, players):

        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Masz mój Miecz", cost=15, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)

        self.addAbility(ability)

        # SpellW
        ability = Ability(name="I mój Łuk", cost=20, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="I mój Topór", cost=30, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="I Swojego Brata", cost=90, cd=8, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="I mój Pierścień, oddaj mi go", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Mithrilowa Kolczuga*", STAT_AR: 25, STAT_MR: 25, STAT_GOLD: 1400}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Tarcza Boromira*", STAT_AR: 15, STAT_MR: 15, STAT_MS: 20, STAT_GOLD: 1900}, {EFFECT_FURY: 2}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Buletkowa Światłość*", STAT_HP: 50, STAT_MANA: 30, STAT_GOLD: 1300}, {EFFECT_HIDE: 2}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Pierścień władzy"}, {EFFECT_HIDE: 1}, autoGold=False)


        self.setStacks(0)


    def shopSpecialItem(self, item: Item):
        if item.getName() == "Pierścień władzy":
            self.changeStacks(1)
            self.changeStat(STAT_HP, -PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()] * self.getStacks())

    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityW(user=self, target=target, ability=ability)
                else:
                    abilityW(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityE(user=self, target=target, ability=ability)
                else:
                    abilityE(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self, onlyDead=True)
            if target != None:
                abilityR(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()
