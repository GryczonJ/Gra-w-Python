from BasicClasses.functions import *
from Heroes.FellowShip.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[1, 1.02, 1.04, 1.08, 1.16],     # Przelicznik AD rzucającego
                           [1, 1.1, 1.2, 1.4, 1.5]]         # Przelicznik AS rzucającego
ABILITYQ_SUPER_VALUES   = [[1.15, 1.2, 1.25, 1.27, 1.3],    # Przelicznik AD rzucającego
                           [1.2, 1.3, 1.4, 1.5, 1.6]]       # Przelicznik AS rzucającego
ABILITYW_VALUES         = [[1, 1.02, 1.05, 1.1, 1.2],       # Przelicznik AD rzucającego
                           [0.5, 0.55, 0.6, 0.65, 0.7],     # Przelicznik MS rzucającego
                           [0.9, 0.85, 0.8, 0.75, 0.7]]     # Przebicie odporności
ABILITYW_SUPER_VALUES   = [[1.15, 1.2, 1.25, 1.3, 1.35],    # Przelicznik AD rzucającego
                           [0.6, 0.65, 0.7, 0.75, 0.8],     # Przelicznik MS rzucającego
                           [0.8, 0.75, 0.7, 0.65, 0.6]]     # Przebicie odporności
ABILITYE_VALUES         = [[1.1, 1.15, 1.2, 1.25, 1.3],     # Przelicznik AD rzucającego
                           [0.8, 0.75, 0.7, 0.65, 0.6]]     # Przebicie odporności
ABILITYE_SUPER_VALUES   = [[1.25, 1.3, 1.35, 1.4, 1.45],    # Przelicznik AD rzucającego
                           [0.7, 0.65, 0.6, 0.55, 0.5]]     # Przebicie odporności
ABILITYR_VALUES         = [[0.4, 0.6, 0.8],                 # Procent HP po odrodzeniu
                           [3, 3, 4],                       # Długość furii celu
                           [2, 2, 1],                       # Długość wyczerpania celu
                           [7, 8, 9]]                       # Długość wirusa celu
PASSIVE_VALUES          = [[45, 40, 35]]                    # Obrażenia od używania pierścienia

def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    repeat = round(user.getAS() * ABILITYQ_VALUES[1][ability.getLevel()])
    dmg = user.getAD() * ABILITYQ_VALUES[0][ability.getLevel()]
    for i in range(repeat):
        user.getADDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)
def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    repeat = round(user.getAS() * ABILITYQ_SUPER_VALUES[1][ability.getLevel()])
    dmg = user.getAD() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()]
    for i in range(repeat):
        user.getADDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)


def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_VALUES[0][ability.getLevel()] + user.getMS() * ABILITYW_VALUES[1][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYW_VALUES[2][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_SUPER_VALUES[0][ability.getLevel()] + user.getMS() * ABILITYW_SUPER_VALUES[1][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYW_SUPER_VALUES[2][ability.getLevel()])
    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYE_VALUES[0][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYE_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYE_SUPER_VALUES[0][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYE_SUPER_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero,target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    target.setHP(int(target.getMAXHP() * ABILITYR_VALUES[0][ability.getLevel()]))
    target.getEffectByKey(EFFECT_FURY).changeCount(int(ABILITYR_VALUES[1][ability.getLevel()]))
    target.getEffectByKey(EFFECT_EXHAUSTION).changeCount(int(ABILITYR_VALUES[2][ability.getLevel()]))
    target.getEffectByKey(EFFECT_DEADLY_VIRUS).changeCount(int(ABILITYR_VALUES[3][ability.getLevel()]))

    user.abilityUsed(ability)