from Heroes.Nasus.abilities import *
from BasicClasses.heroPattern import HeroPattern

class Nasus(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Nasus",
                         HP=225, MAXHP=225, HPREG=10,
                         Mana=50, MAXMana=80, ManaREG=10,
                         AD=15, AP=0, AR=20, MR=20,
                         AS=1, CRIT=0, MS=50, GOLD=600)

    def preparePlayer(self, id, players):
        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Wysysające Uderzenie", cost=10, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Usychanie", cost=20, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Duchowy Ogień", cost=20, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Furia Piasków", cost=80, cd=6, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Pożeracz Dusz", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Laska Faraona*", STAT_AD: 50, STAT_AS: 0.25, STAT_GOLD: 1200}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Błogosławieństwo Ozyrysa*", STAT_AR: 30, STAT_MR: 30, STAT_HP: 50,
                                 STAT_MAXHP: 50, STAT_GOLD: 2000}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Przekleństwo Apisa*", STAT_AD: 40, STAT_AR: 10, STAT_MR: 10,
                                 STAT_MS: 20, STAT_MANAREG: 10, STAT_GOLD: 2400}, autoGold=False)

        self.setStacks(0)

    def getADDMG(self, dmg: float | int, target: HeroPattern, ARperc: int | float = 1.0, CRITLuck: int = 0):
        prevHP = target.getHP()
        super().getADDMG(dmg, target, ARperc)
        nextHP = target.getHP()
        HP = math.ceil((prevHP - nextHP) * PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])
        self.changeStat(STAT_HP, HP)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityQ(user=self, ability=ability)
            else:
                abilityQ(user=self, ability=ability)
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityW(user=self, ability=ability)
            else:
                target = locateEnemy(self)
                if target != None:
                    abilityW(user=self, target=target, ability=ability)
                else:
                    self.lobby()
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                superAbilityE(user=self, ability=ability)
            else:
                target = locateEnemy(self)
                if target != None:
                    abilityE(user=self, target=target, ability=ability)
                else:
                    self.lobby()
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            abilityR(user=self, ability=ability)
        else:
            self.lobby()
