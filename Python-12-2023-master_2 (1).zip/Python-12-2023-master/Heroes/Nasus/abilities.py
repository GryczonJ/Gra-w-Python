from BasicClasses.functions import *
from Heroes.Nasus.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.8, 0.9, 1, 1.1, 1.2],         # Przelicznik AD rzucającego
                           [1, 1, 0.9, 0.9, 0.7],           # Przebicie odporności celu
                           [1, 1, 1, 2, 2],                 # Ilość zabitych stworów
                           [25, 20, 17, 13, 10]]            # Przelicznik złoto -> ładunek
ABILITYQ_SUPER_VALUES   = [[1.1, 1.2, 1.3, 1.4, 1.5],       # Przelicznik AD rzucającego
                           [0.9, 0.85, 0.8, 0.7, 0.65],     # Przebicie odporności celu
                           [2, 2, 2, 3, 3],                 # Ilość zabitych stworów
                           [25, 20, 17, 13, 10],            # Przelicznik złoto -> ładunek
                           [8, 10, 13, 15, 17]]             # Stała ilość ładunków
ABILITYW_VALUES         = [[1, 2, 2, 2, 3]]                 # Długość postarzenia celu
ABILITYW_SUPER_VALUES   = [[2, 2, 2, 3, 3]]                 # Długość postarzenia posostałych
ABILITYE_VALUES         = [[1, 1, 1, 1, 2],                 # Długość rozbrojenia celu
                           [0.3, 0.35, 0.4, 0.45, 0.5],     # Przelicznik AP rzucającego
                           [5, 6, 7, 8, 9]]                 # Ilość powtórzeń obrażeń
ABILITYE_SUPER_VALUES   = [[1, 1, 1, 2, 2],                 # Długość rozbrojenia pozostałych
                           [0.4, 0.45, 0.5, 0.55, 0.6],     # Przelicznik AP rzucającego
                           [6, 7, 8, 9, 10]]                # Ilość powtórzeń obrażeń
ABILITYR_VALUES         = [[3, 4, 5]]                       # Długość postaci faraona rzucającego
PASSIVE_VALUES          = [[0.15, 0.2, 0.25]]               # Kradzież życia
def abilityQ(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    targetType = chooseTargetType()
    if targetType == 2:
        target = locateEnemy(user)
        if target != None:
            dmg = user.getAD() * ABILITYQ_VALUES[0][ability.getLevel()] + user.getStacks()
            user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYQ_VALUES[1][ability.getLevel()])

            user.abilityUsed(ability)
        else:
            user.lobby()
    else:
        prevGold = user.getGOLD()
        if user.getEffectByKey(EFFECT_PHARAOH_FORM).isActive():
            user.farm()
        else:
            user.farm(int(ABILITYQ_VALUES[2][ability.getLevel()]))
        nextGold = user.getGOLD()
        stacks = math.ceil((nextGold - prevGold) / ABILITYQ_VALUES[3][ability.getLevel()])
        user.changeStacks(stacks)
        stacks_msg1(stacks)

        user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    targetType = chooseTargetType()
    if targetType == 2:
        target = locateEnemy(user)
        if target != None:
            dmg = user.getAD() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()] + user.getStacks()
            user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYQ_SUPER_VALUES[1][ability.getLevel()])

            user.abilityUsed(ability)
            user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)
        else:
            user.lobby()
    else:
        prevGold = user.getGOLD()
        if user.getEffectByKey(EFFECT_PHARAOH_FORM).isActive():
            user.farm()
        else:
            user.farm(int(ABILITYQ_SUPER_VALUES[2][ability.getLevel()]))
        nextGold = user.getGOLD()
        stacks = math.ceil((nextGold - prevGold) / ABILITYQ_SUPER_VALUES[3][ability.getLevel()] + ABILITYQ_SUPER_VALUES[4][ability.getLevel()])
        user.changeStacks(stacks)
        stacks_msg1(stacks)

        user.abilityUsed(ability)
        user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    target.getEffectByKey(EFFECT_AGEING).changeCount(ABILITYW_VALUES[0][ability.getLevel()])


    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    for player in user.getPlayers():
        if player == user:
            continue
        player.getEffectByKey(EFFECT_AGEING).changeCount(ABILITYW_SUPER_VALUES[0][ability.getLevel()])


    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    target.getEffectByKey(EFFECT_DISARM).changeCount(ABILITYE_VALUES[0][ability.getLevel()])
    dmg = user.getAP() * ABILITYE_VALUES[1][ability.getLevel()]
    for i in range(int(ABILITYE_VALUES[2][ability.getLevel()])):
        user.getAPDMG(dmg=dmg, target=target)


    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYE_SUPER_VALUES[1][ability.getLevel()]
    for player in user.getPlayers():
        if player == user:
            continue
        player.getEffectByKey(EFFECT_DISARM).changeCount(ABILITYE_SUPER_VALUES[0][ability.getLevel()])
        for i in range(ABILITYE_SUPER_VALUES[2][ability.getLevel()]):
            user.getAPDMG(dmg=dmg, target=player)

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    user.getEffectByKey(EFFECT_PHARAOH_FORM).changeCount(ABILITYR_VALUES[0][ability.getLevel()])


    user.abilityUsed(ability)