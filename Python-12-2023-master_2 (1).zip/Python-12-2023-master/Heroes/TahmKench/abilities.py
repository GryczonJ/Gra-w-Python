from BasicClasses.functions import *
from Heroes.TahmKench.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.9, 1, 1.05, 1.1, 1.2]]        # Przelicznik AP rzucającego
ABILITYQ_SUPER_VALUES   = [[1.1, 1.15, 1.2, 1.3, 1.4]]      # Przelicznik AP rzucającego
ABILITYW_VALUES         = [[0.8, 0.9, 1, 1.1, 1.2],         # Przelicznik AP rzucającego
                           [1, 1, 1, 1, 2]]                 # Długość ogłuszenia celu
ABILITYW_SUPER_VALUES   = [[1, 1.1, 1.2, 1.3, 1.4],         # Przelicznik AP rzucającego
                           [1, 1, 1, 2, 2]]                 # Długość ogłuszenia celu
ABILITYE_VALUES         = [[0.5, 0.55, 0.6, 0.65, 0.7]]     # Procent przywrócenia brakującego HP
ABILITYE_SUPER_VALUES   = [[0.7, 0.75, 0.8, 0.85, 0.9],     # Procent przywrócenia brakującego HP
                           [0.2, 0.25, 0.3, 0.35, 0.4]]     # Przelicznik AP rzucającego
ABILITYR_VALUES         = [[30, 40, 50],                    # Stała wartość obrażeń
                           [0.12, 0.15, 0.2],               # Przelicznik MAXHP celu
                           [0.2, 0.25, 0.3],                # Przelicznik AP rzucającego
                           [1, 2, 2]]                       # Długość ogłuszenia celu
PASSIVE_VALUES          = [[0.05, 0.08, 0.1]]               # Dodatkowe obrażenia od MAXHP atakującego przy ataku

def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYQ_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_STUN).changeCount(ABILITYW_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_STUN).changeCount(ABILITYW_SUPER_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    heal = (user.getMAXHP() - user.getHP()) * ABILITYE_VALUES[0][ability.getLevel()]
    user.changeStat(STAT_HP, heal)

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    heal = (user.getMAXHP() - user.getHP()) * ABILITYE_SUPER_VALUES[0][ability.getLevel()]
    user.changeStat(STAT_HP, heal)
    dmg = heal + user.getAP() * ABILITYE_SUPER_VALUES[1][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    dmg = ABILITYR_VALUES[0][ability.getLevel()] + target.getMAXHP() * ABILITYR_VALUES[1][ability.getLevel()] + user.getAP() * ABILITYR_VALUES[2][ability.getLevel()]
    user.getAPDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_STUN).changeCount(ABILITYR_VALUES[3][ability.getLevel()])

    user.abilityUsed(ability)