from Heroes.TahmKench.abilities import *
from BasicClasses.heroPattern import HeroPattern

class TahmKench(EmptyHero):

        def __init__(self):
            super().__init__(ID=1, Name="TahmKench",
                             HP=300, MAXHP=300, HPREG=15,
                             Mana=80, MAXMana=80, ManaREG=10,
                             AD=10, AP=30, AR=25, MR=25,
                             AS=1, CRIT=0, MS=45, GOLD=600)

        def preparePlayer(self, id, players):
            super().preparePlayer(id, players)

            # SpellQ
            ability = Ability(name="Liźnięcie Jęzorem", cost=10, cd=2, maxLevel=5)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
            self.addAbility(ability)

            #SpellW
            ability = Ability(name="Nurkowanie Otchłani", cost=20, cd=3, maxLevel=5)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
            self.addAbility(ability)

            #SpellE
            ability = Ability(name="Gruba Skóra", cost=20, cd=2, maxLevel=5)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
            self.addAbility(ability)

            # SpellR
            ability = Ability(name="Pożarcie", cost=40, cd=5, maxLevel=3)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
            self.addAbility(ability)

            # Passive
            ability = Ability(name="Nabyty Gust", passive=True, maxLevel=3)
            self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
            self.addAbility(ability)

            self.playerShop.addItem({STAT_NAME: "Stalowe Serce*", STAT_HP: 50, STAT_MAXHP: 50, STAT_MANAREG: 5, STAT_HPREG: 5, STAT_GOLD: 1600}, autoGold=False)
            self.playerShop.addItem({STAT_NAME: "Demoniczny Uścisk*", STAT_AP: 40, STAT_HP: 10, STAT_MAXHP: 10, STAT_GOLD: 1200}, autoGold=False)
            self.playerShop.addItem({STAT_NAME: "Plemienna Zbroja*", STAT_HP: 40, STAT_MAXHP: 40, STAT_HPREG: 5, STAT_GOLD: 1000}, autoGold=False)

        def getADDMG(self, dmg: float | int, target: HeroPattern, ARperc: int | float = 1.0, CRITLuck: int = 0):
            extraDmg = dmg + (PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()] * self.getMAXHP())
            super().getADDMG(dmg + extraDmg, target, ARperc)

        def spellQ(self, ability):
            if self.checkAbility(ability):
                target = locateEnemy(self)
                if target != None:
                    if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                        superAbilityQ(user=self, target=target, ability=ability)
                    else:
                        abilityQ(user=self, target=target, ability=ability)
                else:
                    self.lobby()
            else:
                self.lobby()

        def spellW(self, ability):
            if self.checkAbility(ability):
                target = locateEnemy(self)
                if target != None:
                    if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                        superAbilityW(user=self, target=target, ability=ability)
                    else:
                        abilityW(user=self, target=target, ability=ability)
                else:
                    self.lobby()
            else:
                self.lobby()

        def spellE(self, ability):
            if self.checkAbility(ability):
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    target = locateEnemy(self)
                    if target != None:
                        superAbilityE(user=self, target=target, ability=ability)
                    else:
                        self.lobby()
                else:
                    abilityE(user=self, ability=ability)
            else:
                self.lobby()

        def spellR(self, ability):
            if self.checkAbility(ability):
                target = locateEnemy(self)
                if target != None:
                    abilityR(user=self, target=target, ability=ability)
                else:
                    self.lobby()
            else:
                self.lobby()