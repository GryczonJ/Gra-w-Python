from BasicClasses.functions import *
from Heroes.Pantheon.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.9, 1, 1.1, 1.2, 1.3]]         # Przelicznik AD rzucającego
ABILITYQ_SUPER_VALUES   = [[1.1, 1.2, 1.3, 1.4, 1.4],       # Przelicznik AD rzucającego
                           [0.25, 0.3, 0.35, 0.37, 0.4]]    # Procent MAXHP, definiujący trafienie krytycznie
ABILITYW_VALUES         = [[0.8, 0.9, 1, 1.1, 1.2],         # Przelicznik AD rzucającego
                           [1, 1, 1, 1, 1]]                 # Długość ogłuszenia celu
ABILITYW_SUPER_VALUES   = [[1, 1.1, 1.2, 1.3, 1.4],         # Przelicznik AD rzucającego
                           [1, 1, 1, 1, 2]]                 # Długość ogłuszenia celu
ABILITYE_VALUES         = [[0.25, 0.3, 0.32, 0.4, 0.42],    # Przelicznik AD rzucającego
                           [4, 5, 5, 6, 7],                 # Ilość powtórzeń ataku
                           [1, 1, 1, 1, 2]]                 # Długość tarczowania rzucającego
ABILITYE_SUPER_VALUES   = [[0.15, 0.2, 0.25, 0.27, 0.3],    # Przelicznik AD rzucającego
                           [4, 5, 5, 5, 6],                 # Ilość powtórzeń ataku
                           [1, 1, 1, 1, 2]]                 # Długość tarczowania rzucającego
ABILITYR_VALUES         = [[1, 1, 1],                       # Długość lotu pantheona rzucającego
                           [0, 1, 1],                       # Długość wzmocnionej zdolności rzucającego
                           [0, 0, 1]]                       # Długość świętej tarczy rzucającego
PASSIVE_VALUES          = [[1, 1, 2]]                       # Liczba HP przywracana po zabiciu

def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYQ_VALUES[0][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)

    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()]
    CRITLuck = 0
    if target.getHP() <= target.getMAXHP() * ABILITYQ_SUPER_VALUES[1][ability.getLevel()]:
        CRITLuck = 100
    user.getADDMG(dmg=dmg, target=target, CRITLuck=CRITLuck)

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_VALUES[0][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_STUN).changeCount(ABILITYW_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)
    target.getEffectByKey(EFFECT_STUN).changeCount(ABILITYW_VALUES[1][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYE_VALUES[0][ability.getLevel()]
    for i in range(int(ABILITYE_VALUES[1][ability.getLevel()])):
        user.getADDMG(dmg=dmg, target=target)
    user.getEffectByKey(EFFECT_SHIELDING).changeCount(int(ABILITYE_VALUES[2][ability.getLevel()]))

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYE_SUPER_VALUES[0][ability.getLevel()]
    for i in range(int(ABILITYE_SUPER_VALUES[1][ability.getLevel()])):
        user.getTrueDMG(dmg=dmg, target=target)
    user.getEffectByKey(EFFECT_SHIELDING).changeCount(int(ABILITYE_SUPER_VALUES[2][ability.getLevel()]))

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    user.getEffectByKey(EFFECT_PANTHEON_FLIGHT).changeCount(ABILITYR_VALUES[0][ability.getLevel()])
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(ABILITYR_VALUES[1][ability.getLevel()])
    user.getEffectByKey(EFFECT_SACRED_SHIELD).changeCount(ABILITYR_VALUES[2][ability.getLevel()])

    user.abilityUsed(ability)