from Heroes.Pantheon.abilities import *

class Pantheon(EmptyHero):
    def __init__(self):
        super().__init__(ID=0, Name="Pantheon",
                         HP=220, MAXHP=220, HPREG=10,
                         Mana=70, MAXMana=90, ManaREG=9,
                         AD=35, AP=5, AR=20, MR=20,
                         AS=1.1, CRIT=0, MS=45, GOLD=600)

    def preparePlayer(self, id, players):
        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Kosmiczna Włócznia", cost=25, cd=2, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Skarbiec Tarczy", cost=30, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Atak Egidy", cost=25, cd=3, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Upadek Gwiazd", cost=40, cd=4, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Wola Śmiertelnika", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Ostrze Drakhtarru*", STAT_AD: 50, STAT_MS: 20, STAT_GOLD: 1200}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Włócznia Shojiin*", STAT_AD: 30, STAT_HPREG: 10, STAT_CRIT: 15, STAT_GOLD: 1400}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Jak`Sho*", STAT_AR: 15, STAT_MR: 15, STAT_HP: 40, STAT_GOLD: 1600}, autoGold=False)

        self.setStacks(1)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityW(user=self, target=target, ability=ability)
                else:
                    abilityW(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityE(user=self, target=target, ability=ability)
                else:
                    abilityE(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            abilityR(user=self, ability=ability)
        else:
            self.lobby()

    def abilityUsed(self, ability: Ability):
        if not self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
            self.changeStacks(PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])
            if self.getStacks() >= 4:
                self.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(1)
                self.changeStacks(-4)
        super().abilityUsed(ability)


