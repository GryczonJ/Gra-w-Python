from Heroes.Jewzard.abilities import *

class Jewzard(EmptyHero):

    def __init__(self):
        super().__init__(ID=0, Name="Żydodziej",
                         HP=190, MAXHP=190, HPREG=10,
                         Mana=0, MAXMana=0, ManaREG=0,
                         AD=10, AP=20, AR=5, MR=5,
                         AS=1, CRIT=0, MS=75, GOLD=800)

    def preparePlayer(self, id, players):

        super().preparePlayer(id, players)

        # SpellQ
        ability = Ability(name="Jewjitsu", cost=100, cd=2, costType=STAT_GOLD, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellW
        ability = Ability(name="Obrzekosa", cost=110, cd=3, costType=STAT_GOLD, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellE
        ability = Ability(name="Przeklęta Tarcza", cost=80, cd=3, costType=STAT_GOLD, maxLevel=5)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1000}, autoGold=False)
        self.addAbility(ability)

        # SpellR
        ability = Ability(name="Błogosławieństwo Mojrzesza", cost=400, cd=4, costType=STAT_GOLD, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        # Passive
        ability = Ability(name="Pieniądze = Potęga", passive=True, maxLevel=3)
        self.playerShop.addItem({STAT_NAME: ability.getName(), STAT_GOLD: 1500}, autoGold=False)
        self.addAbility(ability)

        self.playerShop.addItem({STAT_NAME: "Święta Jarmułka*", STAT_MAXHP: 20, STAT_HP: 50, STAT_AR: 15,
                                 STAT_MR: 10, STAT_GOLD: 1300}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Poduszkowe Zaskórniaki*", STAT_MAXHP: -25, STAT_MS: -10,
                                 STAT_GOLD: -1500}, autoGold=False)
        self.playerShop.addItem({STAT_NAME: "Maska Gazowa*", STAT_MAXHP: 50, STAT_HP: 50, STAT_AR: 10,
                                 STAT_MR: 10, STAT_GOLD: 1450}, autoGold=False)

    def spellQ(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityQ(user=self, target=target, ability=ability)
                else:
                    abilityQ(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellW(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityW(user=self, target=target, ability=ability)
                else:
                    abilityW(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellE(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                if self.getEffectByKey(EFFECT_POWER_ABILITY).isActive():
                    superAbilityE(user=self, target=target, ability=ability)
                else:
                    abilityE(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def spellR(self, ability):
        if self.checkAbility(ability):
            target = locateEnemy(self)
            if target != None:
                abilityR(user=self, target=target, ability=ability)
            else:
                self.lobby()
        else:
            self.lobby()

    def getAP(self):
        return math.ceil(super().getAP() + self.getGOLD() * PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])

    def getAD(self):
        return math.ceil(super().getAD() + self.getGOLD() * PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])

    def getStat(self, key):
        if key == STAT_AD or key == STAT_AP:
            return math.ceil(super().getStat(key) + self.getGOLD() * PASSIVE_VALUES[0][self.getAbilityByIndex(9).getLevel()])
        else:
            return super().getStat(key)

    def rest(self):
        super().rest()
        self.changeStat(STAT_GOLD, PASSIVE_VALUES[1][self.getAbilityByIndex(9).getLevel()])