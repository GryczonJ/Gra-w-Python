from BasicClasses.functions import *
from Heroes.Jewzard.messages import *

##### Tablice przeliczników
ABILITYQ_VALUES         = [[0.2, 0.22, 0.25, 0.27, 0.29],   # Przelicznik AP rzucającego
                           [0.05, 0.07, 0.1, 0.12, 0.15],   # Przelicznik MR celu
                           [3, 3, 4, 4, 5],                 # Liczba ataków
                           [1, 1, 1, 1, 0.8],               # Przebicie odporności na magię
                           [5, 8, 10, 12, 15],              # Szansa na ogłuszenie (w procentach)
                           [1, 1, 1, 1, 1]]                 # Długość ogłuszenia celu
ABILITYQ_SUPER_VALUES   = [[0.25, 0.27, 0.3, 0.32, 0.34],   # Przelicznik AP rzucającego
                           [0.10, 0.12, 0.14, 0.16, 0.18],  # Przelicznik MR celu
                           [4, 4, 5, 5, 6],                 # Liczba ataków
                           [1, 0.95, 0.9, 0.8, 0.75],       # Przebicie odporności na magię
                           [10, 12, 14, 16, 18],            # Szansa na ogłuszenie (w procentach)
                           [1, 1, 1, 1, 1]]                 # Długość ogłuszenia celu
ABILITYW_VALUES         = [[0.6, 0.7, 0.8, 0.9, 1],         # Przelicznik AP rzucającego
                           [-3, -4, -5, -6, -7],            # Obniżenie AR celu
                           [-3, -4, -5, -6, -7],            # Obniżenie MR celu
                           [1, 1, 2, 2, 3]]                 # Długość krwawienia celu
ABILITYW_SUPER_VALUES   = [[0.8, 0.9, 1, 1.1, 1.2],         # Przelicznik AP rzucającego
                           [-7, -8, -9, -10, -11],          # Obniżenie AR celu
                           [-7, -8, -9, -10, -11],          # Obniżenie MR celu
                           [1, 2, 3, 3, 3]]                 # Długość krwawienia celu
ABILITYE_VALUES         = [[1, 1, 1, 2, 2],                 # Długość świętej tarczy rzucającego
                           [1, 1, 1, 1, 2],                 # Długośc zawieszenia broni celu
                           [60, 55, 50, 45, 40]]            # Przywrócenie HP celu
ABILITYE_SUPER_VALUES   = [[1, 1, 2, 2, 2],                 # Długość świętej tarczy rzucającego
                           [1, 2, 2, 2, 2],                 # Długośc zawieszenia broni celu
                           [50, 45, 40, 35, 30]]            # Przywrócenie HP celu
ABILITYR_VALUES         = [[17, 20, 25],                    # Bazowe obrażenia zdolności
                           [0.6, 0.7, 0.75],                # Przelicznik AP rzucającego
                           [0.02, 0.4, 0.5],                # Przelicznik złota celu
                           [1, 0.95, 0.9],                  # Przebicie odporności
                           [1, 1, 2]]                       # Długość spowolnienia celu
PASSIVE_VALUES          = [[0.01, 0.02, 0.03],              # Przelicznik: złoto -> AP/AD
                           [50, 75, 100]]                   # Dodatkowy przyrost złota

def abilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYQ_VALUES[0][ability.getLevel()] + target.getMR() * ABILITYQ_VALUES[1][ability.getLevel()]
    for i in range(int(ABILITYQ_VALUES[2][ability.getLevel()])):
        user.getAPDMG(dmg=dmg, target=target)
        if random.randint(0, 100) < ABILITYQ_VALUES[3][ability.getLevel()] :
            target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYQ_VALUES[4][ability.getLevel()]))


    user.abilityUsed(ability)

def superAbilityQ(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAP() * ABILITYQ_SUPER_VALUES[0][ability.getLevel()] + target.getMR() * ABILITYQ_SUPER_VALUES[1][ability.getLevel()]
    for i in range(int(ABILITYQ_SUPER_VALUES[2][ability.getLevel()])):
        user.getAPDMG(dmg=dmg, target=target)
        if random.randint(0, 100) < ABILITYQ_SUPER_VALUES[3][ability.getLevel()]:
            target.getEffectByKey(EFFECT_STUN).changeCount(int(ABILITYQ_SUPER_VALUES[4][ability.getLevel()]))


    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_VALUES[0][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)
    target.changeStat(STAT_AR, value=ABILITYW_VALUES[1][ability.getLevel()])
    target.changeStat(STAT_MR, value=ABILITYW_VALUES[2][ability.getLevel()])
    target.getEffectByKey(EFFECT_BLEED).changeCount(ABILITYW_VALUES[3][ability.getLevel()])


    user.abilityUsed(ability)

def superAbilityW(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    dmg = user.getAD() * ABILITYW_SUPER_VALUES[0][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target)
    target.changeStat(STAT_AR, value=ABILITYW_SUPER_VALUES[1][ability.getLevel()])
    target.changeStat(STAT_MR, value=-ABILITYW_SUPER_VALUES[2][ability.getLevel()])
    target.getEffectByKey(EFFECT_BLEED).changeCount(ABILITYW_SUPER_VALUES[3][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    ability_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.getEffectByKey(EFFECT_SACRED_SHIELD).changeCount(ABILITYE_VALUES[0][ability.getLevel()])
    target.getEffectByKey(EFFECT_CEASEFIRE).changeCount(ABILITYE_VALUES[1][ability.getLevel()])
    target.changeStat(STAT_HP, value=ABILITYE_VALUES[2][ability.getLevel()])

    user.abilityUsed(ability)

def superAbilityE(user: EmptyHero, target: EmptyHero, ability: Ability):
    superAbility_msg1(playerName=user.getName(), abilityName=ability.getName())
    user.getEffectByKey(EFFECT_SACRED_SHIELD).changeCount(ABILITYE_SUPER_VALUES[0][ability.getLevel()])
    target.getEffectByKey(EFFECT_CEASEFIRE).changeCount(ABILITYE_SUPER_VALUES[1][ability.getLevel()])
    target.changeStat(STAT_HP, value=ABILITYE_SUPER_VALUES[2][ability.getLevel()])

    user.abilityUsed(ability)
    user.getEffectByKey(EFFECT_POWER_ABILITY).changeCount(-1)

def abilityR(user: EmptyHero, target: EmptyHero, ability: Ability):
    powerfullAbility(playerName=user.getName(), abilityName=ability.getName())
    dmg = ABILITYR_VALUES[0][ability.getLevel()] + user.getAP() * ABILITYR_VALUES[1][ability.getLevel()] + target.getGOLD() * ABILITYR_VALUES[2][ability.getLevel()]
    user.getADDMG(dmg=dmg, target=target, ARperc=ABILITYR_VALUES[3][ability.getLevel()])
    target.getEffectByKey(EFFECT_SLOWDOWN).changeCount(ABILITYR_VALUES[4][ability.getLevel()])

    user.abilityUsed(ability)