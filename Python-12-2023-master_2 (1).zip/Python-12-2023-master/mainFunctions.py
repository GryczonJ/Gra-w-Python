import copy
import os
from BasicClasses.Modification.functions import *
from BasicClasses.Shop.costs import *

from Heroes.CaveCrawler.caveCrawler import CaveCrawler
from Heroes.ChoGath.choGath import ChoGath
from Heroes.Darius.darius import Darius
from Heroes.FellowShip.fellowShip import FellowShip
from Heroes.Floyd.floyd import Floyd
from Heroes.Heavy.heavy import Heavy
from Heroes.Jewzard.jewzard import Jewzard
from Heroes.Nasus.nasus import Nasus
from Heroes.Obamna.obamna import Obamna
from Heroes.Pantheon.pantheon import Pantheon
from Heroes.Pirate.pirate import Pirate
from Heroes.Rayman.rayman import Rayman
from Heroes.ShadowWalker.shadowWalker import ShadowWalker
from Heroes.TahmKench.tahmKench import TahmKench
from Heroes.Veigar.veigar import Veigar

availableHeroes = [CaveCrawler(), ChoGath(), Darius(), FellowShip(), Floyd(), Heavy(),
                   Jewzard(), Nasus(), Obamna(), Pantheon(), Pirate(),
                   Rayman(), ShadowWalker(), TahmKench(), Veigar()]

def lobby():
    players = []
    while True:
        print("----------[Pojedynki Mistrzów]----------")
        print("Wybierz akcję:")
        print("1. Dodaj graczy")
        print("2. Modyfikuj rozgrywkę")
        print("3. Modyfikuj cennik")
        print("4. Rozpocznij starcie")
        print("Akcja: ", end='')
        akcja = input()
        try:
            akcja = int(akcja)
        except:
            akcja = 0
        if akcja == 1:
            gracz = addPlayer()
            os.system("cls")
            if gracz != None:
                players.append(gracz)
                print("Dodano gracza: " + gracz.getName())
        elif akcja == 2:
            addModyfications()
            os.system("cls")
        elif akcja == 3:
            changeShopCosts()
            os.system("cls")
        elif akcja == 4:
            break
        else:
            os.system("cls")
            print("Wybrano niepoprawny numer akcji")

    return players

def changeShopCosts():
    os.system("cls")
    print("Aktualny przelicznik: " + str(round(STAT_COSTS[STAT_HP]/10,2)))
    print("0. Wyjście")
    print("1. Zmniejsz o 10%")
    print("2. Zmniejsz o 5%")
    print("3. Zmniejsz o 1%")
    print("4. Przywróć")
    print("5. Zwiększ o 1%")
    print("6. Zwiększ o 5%")
    print("7. Zwiększ o 10%")
    print("Akcja: ", end='')
    przelicznik = 1
    akcja = input()
    try:
        akcja = int(akcja)
    except:
        akcja = 0
    if akcja == 0:
        return
    elif akcja == 1:
        przelicznik = 0.9
    elif akcja == 2:
        przelicznik = 0.95
    elif akcja == 3:
        przelicznik = 0.99
    elif akcja == 4:
        przelicznik = round((STAT_COSTS[STAT_HP] - 10)/STAT_COSTS[STAT_HP], 2)
    elif akcja == 5:
        przelicznik = 1.01
    elif akcja == 6:
        przelicznik = 1.05
    elif akcja == 7:
        przelicznik = 1.1
    for key in STAT_COSTS.keys():
        STAT_COSTS[key] = STAT_COSTS[key] * przelicznik
    changeShopCosts()


def addPlayer():
    os.system("cls")
    print("Wybierz Bohatera:")
    print("0. Wyjście")
    for i, hero in enumerate(availableHeroes):
        print(str(i+1) + ". " + hero.getName())
    print("Akcja: ", end='')
    akcja = input()
    try:
        akcja = int(akcja)
    except:
        akcja = 0
    if akcja > 0 and akcja <= len(availableHeroes):
        return copy.deepcopy(availableHeroes[akcja - 1])
    return None

def addModyfications():
    os.system("cls")
    print("Wybierz modyfikacje:")
    i = 0
    print("0. Wyjście")
    for key, value in modificationDict.items():
        i += 1
        print(str(i) + ". " + key + ": " + str(value))
    print("Akcja: ", end='')
    akcja = input()
    try:
        akcja = int(akcja)
    except:
        akcja = 0
    if akcja > 0 and akcja <= len(modificationDict):
        key = list(modificationDict)[akcja - 1]
        modificationDict[key] = (modificationDict[key] + 1) % 2
        addModyfications()
    else:
        return