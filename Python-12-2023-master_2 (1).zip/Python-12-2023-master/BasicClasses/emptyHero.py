from abc import abstractmethod
from BasicClasses.heroPattern import HeroPattern
from BasicClasses.ability import Ability
from BasicClasses.Shop.item import Item
from BasicClasses.Effect.initialize import *
from BasicClasses.Effect.functions import *
from BasicClasses.Event.functions import *
import BasicClasses.functions as fc
import BasicClasses.messages as msg
import math
import random
import os

class EmptyHero(HeroPattern):

    def preparePlayer(self, id, players):
        super().preparePlayer(id, players)

        self.addAbility(Ability(name="Farmienie", cost=0, cd=0, maxLevel=0))
        self.addAbility(Ability(name="Atak fizyczny", cost=0, cd=0, maxLevel=0))
        self.addAbility(Ability(name="Obrona", cost=0, cd=0, maxLevel=0))
        self.addAbility(Ability(name="Sklep", cost=0, cd=0, maxLevel=0))
        self.addAbility(Ability(name="Odpoczynek", cost=0, cd=0, maxLevel=0))

        prepareEffectList(self)

    def printPlayers(self):
        for key, value in self.getActualEvents().items():
            print(key + ": " + str(value))
        for player in self.getPlayers():
            print(player)

    def preLobby(self):
        print("", end='')

    def postLobby(self, action: int):
        print("", end='')

    def lobby(self):
        msg.lineSeparator()
        self.printPlayers()
        msg.lineSeparator()
        if not self.isAlive():
            print("Nie żyje, nie może wykonać akcji")
            return
        self.preLobby()
        print("Jaką akcję chcesz podjąć " + self.getName() + "?")
        self.printAbilities()
        print("Akcja: ", end='')
        action = fc.stringToInt(input())
        self.postLobby(action)
        self.acionSwitch(action)

    def acionSwitch(self, action):
        if action == 1:
            self.farm()
        elif action == 2:
            self.attack()
        elif action == 3:
            self.defence()
        elif action == 4:
            self.shop()
            self.lobby()
        elif action == 5:
            self.rest()
        elif action == 6:
            self.spellQ(self.getAbilityByIndex(5))
        elif action == 7:
            self.spellW(self.getAbilityByIndex(6))
        elif action == 8:
            self.spellE(self.getAbilityByIndex(7))
        elif action == 9:
            self.spellR(self.getAbilityByIndex(8))
        else:
            msg.lineSeparator()
            msg.incorrectAction()
            self.lobby()

    def farm(self, staticRepeat: int = 0, minions: None | list = None):
        msg.startFarm()
        if minions == None:
            minions = [50, 80, 100, 200]
        if EVENT_DOUBLE_FARM in self.getActualEvents():
            for i in range(len(minions)):
                minions[i] = minions[i] * 2
        repeat = staticRepeat
        if repeat == 0:
            repeat = math.ceil((2 * self.getAS()) + (self.getMS() * 0.05))
        farmLuck = 0
        if self.getEffectByKey(EFFECT_LUCK).isActive():
            msg.activeLuck()
            farmLuck = 50
        self.changeStat(STAT_GOLD, fc.farmRandomizer(minions, repeat, farmLuck))

    def attack(self):
        target = fc.locateEnemy(self)
        if target == None:
            self.lobby()
            return
        repeat = round(self.getAS())
        for i in range(repeat):
            self.getADDMG(self.getAD(), target)

    def checkCRIT(self, dmg: float | int, CRITLuck: int = 0) -> float | int:
        if random.randint(0, 100) < self.getCRIT() + CRITLuck:
            msg.crititalHit()
            return dmg * self.getCritDMG()
        else:
            return dmg

    def getADDMG(self, dmg: float | int, target: HeroPattern, ARperc: int | float = 1.0, CRITLuck: int = 0):
        dmg = self.checkCRIT(dmg, CRITLuck)
        targetResist = target.getAR()
        if ARperc <= 1 and ARperc >= 0:
            targetResist = targetResist * ARperc
        else:
            targetResist = targetResist - ARperc
        if targetResist <= -100:
            targetResist = -99.999999999999
        dmg = math.ceil((dmg * 100) / (100 + targetResist))
        backpackEffectProceed(self, [STAT_AD, STAT_AS, STAT_MS])
        # dmg = math.ceil(dmg - targetResist)
        if target.getEffectByKey(EFFECT_SHIELDING).isActive():
            msg.activeShielding()
            dmg = 0
        elif target.getEffectByKey(EFFECT_SACRED_SHIELD).isActive():
            msg.activeSacredShield()
            dmg = 0
            target.getEffectByKey(EFFECT_SACRED_SHIELD).changeCount(-1)
        if dmg <= 0:
            msg.noPenetration(self.getName())
            return
        msg.dmgDealt(dmg, STAT_AD, target.getName())
        target.changeStat(STAT_HP, -dmg)
        backpackEffectProceed(target, [STAT_MAXHP, STAT_AR])

    def getAPDMG(self, dmg: float | int, target: HeroPattern, MRperc: int | float = 1.0, CRITLuck: int = 0):
        dmg = self.checkCRIT(dmg, -200 + CRITLuck)
        targetResist = target.getMR()
        if MRperc <= 1 and MRperc >= 0:
            targetResist = targetResist * MRperc
        else:
            targetResist = targetResist - MRperc
        if targetResist <= -100:
            targetResist = -99.9999
        dmg = math.ceil((dmg * 100) / (100 + targetResist))
        backpackEffectProceed(self, [STAT_AP, STAT_MAXMANA])
        # dmg = math.ceil(dmg - targetResist)
        if target.getEffectByKey(EFFECT_SHIELDING).isActive():
            msg.activeShielding()
            dmg = 0
        elif target.getEffectByKey(EFFECT_SACRED_SHIELD).isActive():
            msg.activeSacredShield()
            dmg = 0
            target.getEffectByKey(EFFECT_SACRED_SHIELD).changeCount(-1)
        if dmg <= 0:
            msg.noPenetration(self.getName())
            return
        msg.dmgDealt(dmg, STAT_AD, target.getName())
        target.changeStat(STAT_HP, -dmg)
        backpackEffectProceed(target, [STAT_MAXHP, STAT_MR])

    def getTrueDMG(self, dmg: float | int, target: HeroPattern, CRITLuck: int = 0):
        dmg = self.checkCRIT(dmg, -300 + CRITLuck)
        backpackEffectProceed(self, [STAT_AD, STAT_AP, STAT_MAXMANA, STAT_AS, STAT_MS])
        if target.getEffectByKey(EFFECT_SHIELDING).isActive():
            msg.activeShielding()
            dmg = 0
        elif target.getEffectByKey(EFFECT_SACRED_SHIELD).isActive():
            msg.activeSacredShield()
            dmg = 0
            target.getEffectByKey(EFFECT_SACRED_SHIELD).changeCount(-1)
        if dmg <= 0:
            msg.noPenetration(self.getName())
            return

        dmg = math.ceil(dmg)
        msg.dmgDealt(dmg, "TRUE", target.getName())
        target.changeStat(STAT_HP, -dmg)
        backpackEffectProceed(target, [STAT_MAXHP, STAT_MR, STAT_AR])

    def defence(self):
        msg.afterDefence(self.getName())
        self.changeStat(STAT_AR, 5)
        self.changeStat(STAT_MR, 5)

    def rest(self):
        msg.afterRest(self.getName())
        self.changeStat(STAT_MANA, self.getManaREG())
        self.changeStat(STAT_HP, self.getHPREG())
        self.changeStat(STAT_GOLD, 50)

    def shop(self):
        msg.lineSeparator()
        print(self)
        msg.lineSeparator()
        if not self.isAlive():
            print("Nie żyje, nie może wykonać akcji")
            return
        print("Co chcesz kupić?")
        if self.getShopToken() > 0:
            print("Posiadane Tokeny: " + str(self.getShopToken()))
        print("0 | Wyjście")
        self.getShop().getFiltredItems()
        msg.lineSeparator()
        print(self)
        msg.lineSeparator()
        print("Podaj ID przedmiotu: ", end='')
        searchID = input()
        if searchID in STAT_KEYS:
            self.getShop().setFilter(searchID)
        elif searchID == "":
            self.getShop().setFilter("")
        itemID = fc.stringToInt(searchID)
        if itemID == 0:
            return
        item = self.getShop().search(itemID)
        if item != None:
            if self.getGOLD() >= item.getGOLD():
                self.shopChangeStatAfterBuy(item)
            elif self.getShopToken() > 0:
                print("Token zakupu został wykorzystany, otrzymałeś środki potrzebne na zakup przedmiotu")
                self.changeShopToken(-1)
                self.changeStat(STAT_GOLD, item.getGOLD())
                self.shopChangeStatAfterBuy(item)
            else:
                print("Nie stać Cię")
        else:
            if (self.getShop().getFilter() == searchID):
                print("Pomyślnie zastosowano filtr")
            else:
                print("Nie znaleziono przedmiotu")
        self.shop()

    def shopChangeStatAfterBuy(self, item: Item, goldUsed: bool = True):
        if goldUsed:
            self.changeStat(STAT_GOLD, -item.getStat(STAT_GOLD))
        for key in item.stats.keys():
            if key == STAT_GOLD:
                continue
            self.changeStat(key, item.getStat(key))
        if item.getName()[-1] == "*":
            self.getShop().items.remove(item)
        for effect in item.getEffects():
            self.getEffectByKey(effect.getName()).changeCount(effect.getCount())
        for ability in self.getAbilities():
            if item.getName() == ability.getName():
                ability.changeLevel(1)
                if ability.getLevel() == ability.getMaxLevel():
                    self.getShop().items.remove(item)
                break
        self.shopSpecialItem(item)
        print("Zakupy pomyślne")
        item.changeStat(STAT_GOLD, math.ceil(item.getGOLD() * 0.1), blockMsg=True, blockStatLimit=True)

    def shopSpecialItem(self, item: Item):
        print("", end='')

    def startTurn(self):
        if not self.isAlive():
            msg.lineSeparator()
            print("Gracz: " + self.getName() + " nie żyje i nie może podjąć akcji")
            return
        if self.canChooseAction():
            passingEffects(self)
            # TO DO:
            # Naprawienie zdolności nasusa
            self.lobby()
        elif self.getEffectByKey(EFFECT_PANTHEON_FLIGHT).isActive():
            msg.lineSeparator()
            passingEffects(self)
            print(self.getName() + " ląduje z obrażeniami")
            for player in self.players:
                if player != self:
                    self.getADDMG(40 + self.getAD() * 0.4, player)
            self.setEffectByKey(EFFECT_PANTHEON_FLIGHT, 0)
        else:
            msg.lineSeparator()
            print(self.getName() + " został ogłuszony i musi odpocząć")
            passingEffects(self)
            self.rest()
            self.getEffectByKey(EFFECT_STUN).changeCount(-1)

    def endTurn(self):
        if not self.isAlive():
            return
        self.rest()
        for ability in self.getAbilities():
            if not ability.isPassive() and ability.getCurrCD() > 0:
                ability.changeCurrCD(-1)
        stateEffects(self)
        self.reduceActualEvents()

    def getLocated(self):
        print("", end='')

    def isTargetable(self) -> bool:
        if not self.getEffectByKey(EFFECT_TRUE_VISION).isActive() and (
                self.getEffectByKey(EFFECT_HIDE).isActive() or
                self.getEffectByKey(EFFECT_PANTHEON_FLIGHT).isActive()
        ):
            return False
        return True


    @abstractmethod
    def spellQ(self, ability: Ability):
        print("Nie posiadasz tej zdolności")

    @abstractmethod
    def spellW(self, ability: Ability):
        print("Nie posiadasz tej zdolności")

    @abstractmethod
    def spellE(self, ability: Ability):
        print("Nie posiadasz tej zdolności")
    @abstractmethod
    def spellR(self, ability: Ability):
        print("Nie posiadasz tej zdolności")

    def __str__(self):
        text = "" + str(self.getID()) + ". " + self.getName()
        text += " |" + STAT_HP + ": " + str(self.getHP()) + "/" + str(self.getMAXHP()) + " (+" + str(self.getHPREG()) + ")"
        text += " |" + STAT_MANA + ": " + str(self.getMana()) + "/" + str(self.getMAXMana()) + " (+" + str(self.getManaREG()) + ")"
        text += " |" + STAT_AD + ": " + str(self.getAD()) + " |" + STAT_AP + ": " + str(self.getAP())
        text += " |RES: " + str(self.getAR()) + "/" + str(self.getMR())
        text += " |" + STAT_AS + ": " + str(self.getAS()) + " |" + STAT_CRIT + ": " + str(self.getCRIT())
        text += " |" + STAT_MS + ": " + str(self.getMS()) + " |" + STAT_GOLD + ": " + str(self.getGOLD())
        for effect in self.getEffects():
            if effect.isActive():
                text += " |" + effect.getName() + " - " + str(effect.getCount())
        if self.getStacks() != -1:
            text += " |Staki: " + str(self.getStacks())
        return text

    def checkAbility(self, ability: Ability, message: bool = True):
        if ability.getCurrCD() > 0:
            if message:
                os.system("cls")
                print("Ta zdolność jeszcze się odnawia")
            return False
        elif ability.getCurrCost() > self.getStat(ability.getCostType()):
            if message:
                os.system("cls")
                print("Masz za mało many")
            return False
        return True

    def abilityUsed(self, ability: Ability):
        self.changeStat(ability.getCostType(), -ability.getCurrCost())
        ability.setCurrCD(ability.getDefCD())
        ability.setCurrCost(ability.getDefCost())

    def canChooseAction(self) -> bool:
        for effect in self.getEffects():
            if effect.isActive() and effect.getBlockActions():
                return False
        return True