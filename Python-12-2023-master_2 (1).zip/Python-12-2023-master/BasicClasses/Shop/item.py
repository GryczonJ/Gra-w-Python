from BasicClasses.stats import Stats

class Item(Stats):

    def __init__(self):
        super().__init__()

    def __str__(self):
        text = str(self.getID()) + " | " + self.getName() + " | "
        for key in self.stats:
            if key != "ID" and key != "Name" and self.getStat(key) != 0:
                text += key + ": " + str(self.getStat(key)) + " | "
        for effect in self.getEffects():
            text += effect.getName() + ": " + str(effect.getCount()) + " | "
        return text