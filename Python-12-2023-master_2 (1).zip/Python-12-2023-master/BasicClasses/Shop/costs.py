from BasicClasses.dictionary import *

########## STATS ##########

# Koszt za sztukę
STAT_COSTS = {
    STAT_HP     : 10,
    STAT_MAXHP  : 10,
    STAT_HPREG  : 50,
    STAT_MANA   : 10,
    STAT_MAXMANA: 10,
    STAT_MANAREG: 70,
    STAT_AD     : 25,
    STAT_CRIT   : 30,
    STAT_AP     : 30,
    STAT_AR     : 30,
    STAT_MR     : 40,
    STAT_AS     : 2000,
    STAT_MS     : 20
}

########## EFFECTS ##########

# Koszt za czas trwania 1 tura
EFFECT_COSTS = {
    EFFECT_BLEED            : 0,
    EFFECT_FURY             : 600,
    EFFECT_HIDE             : 600,
    EFFECT_LUCK             : 600,
    EFFECT_PANTHEON_FLIGHT  : 500,
    EFFECT_POWER_ABILITY    : 2000,
    EFFECT_STUN             : 0,
    EFFECT_DEADLY_VIRUS     : -350
}