import math

from BasicClasses.Shop.item import Item
from BasicClasses.Effect.effect import Effect
from BasicClasses.Shop.initialize import *
from BasicClasses.Shop.costs import *
from BasicClasses.dictionary import *

class Shop():

    def __init__(self):

        self.items = []
        self.filter = ""
        initializeShop(self)

    def addItem(self, item_stats, effect_stats = None, autoGold = True):
        GOLD = 0
        discount = [0, -1]
        item = Item()
        for key, value in item_stats.items():
            item.setStat(key, value)
            if key in STAT_COSTS:
                discount[0] += value
                discount[1] += 1
                GOLD += (STAT_COSTS[key] * value)
        if effect_stats != None:
            for key, value in effect_stats.items():
                item.addEffect(Effect(key, value))
                if key in EFFECT_COSTS:
                    GOLD += EFFECT_COSTS[key] * value
        item.setID(len(self.items) + 1)
        if autoGold:
            if discount[1] > 0:
                GOLD = GOLD - (discount[0] * discount[1])
            item.setGOLD(math.ceil(GOLD))
        self.items.append(item)

    def search(self, id: int) -> Item | None:
        for item in self.items:
            if item.getID() == id:
                return item
        return None

    def __str__(self):
        text = ""
        for item in self.items:
            text += item.__str__() + "\n"
        return text

    def getFiltredItems(self):
        text = ""
        for item in self.items:
            if self.getFilter() == "" or item.getStat(self.getFilter()) != 0:
                text += item.__str__() + "\n"
        print(text)

    def setFilter(self, filter: str):
        self.filter = filter

    def getFilter(self) -> str:
        return self.filter