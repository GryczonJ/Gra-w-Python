import random
import math
from BasicClasses.messages import *
from BasicClasses.emptyHero import EmptyHero
from BasicClasses.ability import Ability
from BasicClasses.dictionary import *

def stringToInt(text: str) -> int:
    try:
        value = int(text)
    except:
        value = -1
    return value

def farmRandomizer(minions: list, repeat: int, farmLuck: int) -> int:
    GOLD = 0
    for i in range(repeat):
        luck = random.randint(0, 100) + farmLuck
        currLuck(luck)
        if luck > 95:
            rarityDrop(3, minions[3], STAT_GOLD)
            GOLD += minions[3]
        elif luck > 80:
            rarityDrop(2, minions[2], STAT_GOLD)
            GOLD += minions[2]
        elif luck > 40:
            rarityDrop(1, minions[1], STAT_GOLD)
            GOLD += minions[1]
        else:
            rarityDrop(0, minions[0], STAT_GOLD)
            GOLD += minions[0]
    totalValue(GOLD, STAT_GOLD)
    return GOLD

def locateEnemy(user: EmptyHero, deadTarget: bool = False,
                untargetable: bool = False, selfTarget: bool = False,
                onlyDead: bool = False, autoTarget: bool = False) -> EmptyHero | None:
    targets = list()
    if onlyDead:
        for player in user.getPlayers():
            if not player.isAlive():
                targets.append(player)
    else:
        for player in user.getPlayers():
            if (
                    (player != user or selfTarget) and
                    (player.isTargetable() or untargetable) and
                    (player.isAlive() or deadTarget)
            ):
                targets.append(player)
    if len(targets) == 0:
        emptyTargets()
        return None
    if not autoTarget:
        print("Wybierz swój cel: ")
        for i, player in enumerate(targets):
            print(str(i + 1) + ". " + player.getName())
        print("Identyfikator wroga: ", end='')
        target = stringToInt(input()) - 1
    else:
        target = random.randint(0, len(targets) - 1)
    if target >= 0 and target < len(targets):
        targets[target].getLocated()
        return targets[target]
    else:
        incorrectTarget()

    return None

def chooseTargetType() -> int:
    lineSeparator()
    print("Kto ma być Twoim celem?")
    print("1. Stwory")
    print("2. Bohater")
    print("ID celu: ", end='')
    targetType = input()
    return stringToInt(targetType)

def statDrain(fromTarget: EmptyHero, toTarget: EmptyHero, key: str, perc: float = 1, value: int = 0):
    if perc != 1:
        drain = fromTarget.getStat(key) * perc
    else:
        drain = fromTarget.getStat(key)
        if drain > value:
            drain = value
    toTarget.changeStat(key, drain)
    fromTarget.changeStat(key, -drain)