def lineSeparator():
    print("-------------------------------------------------------------------")

def incorrectAction():
    print("Wybrano niepoprawną akcję")

def incorrectTarget():
    print("Wybrano niepoprawny cel ataku")

def emptyTargets():
    print("Brak dostępnych celów ataku")

def notEnoughMana():
    print("Masz za mało many")

def leaveShop():
    print("Zapraszamy ponownie")

def startFarm():
    print("Postanowiłeś trochę pofarmić")

def activeLuck():
    print("Szczęście wpływa na obecną operację")

def activeShielding():
    print("Tarczowanie wpływa na obecna operację")

def activeSacredShield():
    print("Święta tarcza zredukowała obrażenia")

def currLuck(luck: int):
    print("Twój poziom szczęścia: " + str(luck) + "%")

def totalValue(value: int | float, type: str):
    print("W sumie: " + str(value) + " " + type)

def crititalHit():
    print("Trafienie krytyczne")

def noPenetration(userName: str):
    print(userName + " nie przaebił się przez obronę")

def dmgDealt(value: int | float, type: str, targetName: str):
    text = "Zadałeś " + str(value) + " obrażeń "
    if type == "AD":
        text += "fizycznych"
    elif type == "AP":
        text += "magicznych"
    elif type == "TRUE":
        text += "nieuchronnych"
    else:
        text += "pochodzenia niewiadomego"
    text += " postaci: " + targetName
    print(text)

def rarityDrop(rarity: int, value: float | int, type: str):
    if rarity == 0:
        text = "Przeciętny łup: "
    elif rarity == 1:
        text = "Rzadki łup: "
    elif rarity == 2:
        text = "Epikci łup: "
    elif rarity == 3:
        text = "Legendarna zdobycz: "
    else:
        text = "Nieokreślony łup: "
    print(text + str(value) + " " + type)

def afterChangeStat(value: int | float, type: str, playerName: str):
    text = playerName + ": "
    if value >= 0:
        text += "Statystyka wzrosła: " + str(value) + " " + type
    else:
        text += "Statystyka zmalała: " + str(value) + " " + type
    print(text)

def afterRest(playerName: str):
    print(playerName + " odpoczywa")

def afterDefence(playerName: str):
    print(playerName + " przyjmuje postawę obronną")

def powerAbility(name: str):
    print("Wzmociona zdolność: " + name)

def endEffect(name: str):
    print("Zakończenie działania efektu: " + name)

def beforeAbility(userName: str, abilityName: str):
    print(userName + " użył zdolności " + abilityName)

def addEffectMsg(userName: str, effectName: str):
    print(userName + " otrzymał efekt " + effectName)

def lostStacks(userName: str, stacks: int):
    print(userName + " nie wykonał zadania i utracił ładunki w liczbie: " + str(stacks))