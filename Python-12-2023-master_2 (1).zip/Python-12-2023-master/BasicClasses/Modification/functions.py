from BasicClasses.dictionary import *

modificationDict = {
    MODIFICATION_CHAOTIC_WEATHER    : 0,
    MODIFICATION_DOUBLE_TROUBLE     : 0,
    MODIFICATION_GOOD_BEGINNING     : 0,
    MODIFICATION_METEOR_SHOWER      : 0,
    MODIFICATION_ONE_SHOT_CONTEST   : 0,
    MODIFICATION_TOXIC_FUMES        : 0
}

def modificationTable():

    if modificationDict[MODIFICATION_CHAOTIC_WEATHER] != 0:
        print("")
    elif modificationDict[MODIFICATION_DOUBLE_TROUBLE] != 0:
        print("")
    elif modificationDict[MODIFICATION_GOOD_BEGINNING] != 0:
        print("")
    elif modificationDict[MODIFICATION_METEOR_SHOWER] != 0:
        print("")
    elif modificationDict[MODIFICATION_ONE_SHOT_CONTEST] != 0:
        print("")
    elif modificationDict[MODIFICATION_TOXIC_FUMES] != 0:
        print("")