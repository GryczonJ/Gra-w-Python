
from BasicClasses.Shop.shop import Shop
from BasicClasses.stats import Stats
from BasicClasses.ability import Ability
class HeroPattern(Stats):

    def preparePlayer(self, id, players):

        self.abilities = list()
        self.effects = list()
        self.events = dict()
        self.players = list()
        self.playerShop = Shop()
        self.tempStats = dict()

        self.CRITDMG = 1.5
        self.LIFESTEAL = 0.2
        self.STACKS = -1

        self.setPlayers(players)
        self.setID(id)
        self.setName(self.getName() + "(" + str(self.getID()) + ")")

        self.actualEvents = {}
        self.dmgContainer = 0
        self.shopToken = 0

    def setShopToken(self, value: int):
        self.shopToken = value

    def getShopToken(self) -> int:
        return self.shopToken

    def changeShopToken(self, value: int):
        self.shopToken += value

    def setDmgContainer(self, value: int):
        self.dmgContainer = value

    def getDmgContainer(self) -> int:
        return self.dmgContainer

    def changeDmgContainer(self, value: int):
        self.dmgContainer += value

    def setAbilities(self, abilities: list):
        self.abilities = abilities

    def getAbilities(self) -> list:
        return self.abilities

    def addAbility(self, ability: Ability):
        self.abilities.append(ability)

    def printAbilities(self):
        for i, ability in enumerate(self.getAbilities()):
            print(str(i + 1) + ". " + ability.getInfo())

    def getAbilityByIndex(self, index) -> Ability:
        return self.abilities[index]

    def setPlayers(self, players: list):
        self.players = players

    def getPlayers(self) -> list:
        return self.players
    def setShop(self, playerShop: Shop):
        self.playerShop = playerShop

    def getShop(self) -> Shop:
        return self.playerShop

    def setTempStats(self, tempStats: dict):
        self.tempStats = tempStats

    def getTempStats(self) -> dict:
        return self.tempStats

    def getTempStatByKey(self, key: str) -> dict:
        return self.tempStats[key]

    def changeTempStats(self, key: str, value: list):
        self.tempStats[key] = value

    def delTempStatByKey(self, key: str):
        del self.tempStats[key]

    def setLifeSteal(self, value: float):
        self.LIFESTEAL = value

    def getLifeSteal(self) -> float:
        return self.LIFESTEAL

    def changeLifeSteal(self, value: float):
        self.LIFESTEAL += value

    def setCritDMG(self, value: float):
        self.CRITDMG = value

    def getCritDMG(self) -> float:
        return self.CRITDMG

    def changeCritDMG(self, value: float):
        self.CRITDMG += value

    def setStacks(self, value: int):
        self.STACKS = value

    def getStacks(self) -> int:
        return self.STACKS

    def changeStacks(self, value: int):
        self.STACKS += value

    def setActualEvents(self, actualEvents: dict):
        self.actualEvents = actualEvents

    def getActualEvents(self) -> dict:
        return self.actualEvents

    def changeActualEventByKey(self, key: str, value: int):
        if key in self.actualEvents:
            self.actualEvents[key] += value
            if self.actualEvents[key] == 0:
                self.deleteActualEventByKey(key)
        else:
            self.addActualEvent(key, value)

    def addActualEvent(self, key: str, value: int):
        self.actualEvents[key] = value

    def deleteActualEventByKey(self, key: str):
        del self.actualEvents[key]

    def isAlive(self) -> bool:
        if self.getHP() <= 0:
            return False
        return True

    def reduceActualEvents(self):
        keys = list(self.getActualEvents())
        for key in keys:
            self.changeActualEventByKey(key, -1)