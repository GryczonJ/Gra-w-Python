class Ability():

    def __init__(self, name: str, cost: int = 50, cd: int = 5, passive: bool = False, costType: str = "Mana", level: int = 1, maxLevel: int = 1):

        self.info = {
            "Name"      : name,         # Nazwa
            "CurrCost"  : cost,         # Aktualny koszt
            "DefCost"   : cost,         # Bazowy koszt
            "CostType"  : costType,     # Waluta kosztu
            "CurrCD"    : 0,            # Aktualny czas odnowienia
            "DefCD"     : cd,           # Czas odnowienia po użyciu
            "BaseCD"    : cd,           # Bazowy czas odnowienia
            "Passive"   : passive,      # Akywna lub pasywna
            "Level"     : level - 1,    # Aktualny poziom umiejętności
            "MaxLevel"  : maxLevel - 1  # Maksymalny poziom umiejętności
        }

    def setName(self, name: str):
        self.info["Name"] = name

    def getName(self) -> str:
        return self.info["Name"]

    def setCurrCost(self, currCost: int):
        self.info["CurrCost"] = currCost

    def getCurrCost(self) -> int:
        return self.info["CurrCost"]

    def setDefCost(self, defCost: int):
        self.info["DefCost"] = defCost

    def getDefCost(self) -> int:
        return self.info["DefCost"]

    def setCostType(self, key: str):
        self.info["CostType"] = key

    def getCostType(self) -> str:
        return self.info["CostType"]

    def changeDefCost(self, value: int):
        self.info["DefCost"] += value

    def setCurrCD(self, currCD: int):
        self.info["CurrCD"] = currCD

    def getCurrCD(self) -> int:
        return self.info["CurrCD"]

    def changeCurrCD(self, value: int):
        self.info["CurrCD"] += value

    def setDefCD(self, defCD: int):
        self.info["DefCD"] = defCD

    def getDefCD(self) -> int:
        return self.info["DefCD"]

    def setBaseCD(self, baseCD: int):
        self.info["BaseCD"] = baseCD

    def getBaseCD(self) -> int:
        return self.info["BaseCD"]

    def setPassive(self, passive: bool):
        self.info["Passive"] = passive

    def isPassive(self) -> bool:
        return self.info["Passive"]

    def setLevel(self, level: int):
        self.info["Level"] = level

    def getLevel(self) -> int:
        return self.info["Level"]

    def changeLevel(self, value: int):
        if self.getLevel() + value > self.getMaxLevel():
            self.setLevel(self.getMaxLevel())
        else:
            self.info["Level"] += value

    def setMaxLevel(self, level: int):
        self.info["MaxLevel"] = level

    def getMaxLevel(self) -> int:
        return self.info["MaxLevel"]

    def getInfo(self):
        text = self.getName() + "(" + str(self.getLevel() + 1) + "/" + str(self.getMaxLevel() + 1) + ")"
        if self.getMaxLevel() == -1:
            text = self.getName()
        if self.isPassive():
            text += ": Bierne"
        else:
            if self.getCurrCD() == 0:
                text += " - Dostępna"
                if self.getCurrCost() != 0 or self.getDefCD() != 0:
                    text += ": (" + self.getCostType() + ": " + str(self.getCurrCost()) + ", Tury: " + str(self.getDefCD()) + ")"
            else:
                text += " - Niedostępna: (Tury: " + str(self.getCurrCD()) + ")"
        return text