import math
from BasicClasses.messages import *
from BasicClasses.Effect.effect import Effect
from BasicClasses.dictionary import *
class Stats:

    def __init__(self, ID = 0, Name = "", HP = 0, MAXHP = 0, HPREG = 0, Mana = 0, MAXMana = 0, ManaREG = 0, AD = 0, CRIT = 0, AR = 0, AP = 0, MR = 0, AS = 0, MS = 0, GOLD = 0):
        self.stats = {
            STAT_ID         : ID,       # Identyfikator postaci
            STAT_NAME       : Name,     # Nazwa postaci
            STAT_MAXHP      : MAXHP,    # Maksymalne punkty zdrowia
            STAT_HP         : HP,       # Punkty zdrowia
            STAT_HPREG      : HPREG,    # Regeneracja zdrowia
            STAT_MAXMANA    : MAXMana,  # Maksymalna mana
            STAT_MANA       : Mana,     # Punkty many
            STAT_MANAREG    : ManaREG,  # Regeneracja many
            STAT_AD         : AD,       # Obrażenie ataku
            STAT_CRIT       : CRIT,     # Szansa na trafienie krytyczne - podawane w %
            STAT_AR         : AR,       # Pancerz
            STAT_AP         : AP,       # Moc umiejętnośći
            STAT_MR         : MR,       # Odporność na magię
            STAT_AS         : AS,       # Prędkość ataku
            STAT_MS         : MS,       # Prędkość
            STAT_GOLD       : GOLD      # Złoto
        }

        self.effects = list()

    def setEffects(self, effects: list):
        self.effects = effects

    def getEffects(self) -> list:
        return self.effects

    def addEffect(self, effect: Effect):
        self.effects.append(effect)

    def getEffectByKey(self, key: str) -> Effect:
        for effect in self.effects:
            if effect.getName() == key:
                return effect

    def setEffectByKey(self, key: str, value: int):
        effect = self.getEffectByKey(key)
        effect.setCount(value)

    def changeEffectByKey(self, key: str, value: int):
        addEffectMsg(self.getName(), key)
        effect = self.getEffectByKey(key)
        effect.changeCount(value)

    def getID(self):
        return self.stats[STAT_ID]

    def setID(self, ID):
        self.stats[STAT_ID] = ID

    def getName(self):
        return self.stats[STAT_NAME]

    def setName(self, Name):
        self.stats[STAT_NAME] = Name

    def getHP(self):
        return self.stats[STAT_HP]

    def setHP(self, HP):
        self.stats[STAT_HP] = HP

    def getMAXHP(self):
        return self.stats[STAT_MAXHP]

    def setMAXHP(self, MAXHP):
        self.stats[STAT_MAXHP] = MAXHP

    def getHPREG(self):
        return self.stats[STAT_HPREG]

    def setHPREG(self, HPREG):
        self.stats[STAT_HPREG] = HPREG

    def getMana(self):
        return self.stats[STAT_MANA]

    def setMana(self, Mana):
        self.stats[STAT_MANA] = Mana

    def getMAXMana(self):
        return self.stats[STAT_MAXMANA]

    def setMAXMana(self, MAXMana):
        self.stats[STAT_MAXMANA] = MAXMana

    def getManaREG(self):
        return self.stats[STAT_MANAREG]

    def setManaREG(self, ManaREG):
        self.stats[STAT_MANAREG] = ManaREG

    def getAD(self):
        return self.stats[STAT_AD]

    def setAD(self, AD):
        self.stats[STAT_AD] = AD

    def getCRIT(self):
        return self.stats[STAT_CRIT]

    def setCRIT(self, CRIT):
        self.stats[STAT_CRIT] = CRIT

    def getAR(self):
        return self.stats[STAT_AR]

    def setAR(self, AR):
        self.stats[STAT_AR] = AR

    def getAP(self):
        return self.stats[STAT_AP]

    def setAP(self, AP):
        self.stats[STAT_AP] = AP

    def getMR(self):
        return self.stats[STAT_MR]

    def setMR(self, MR):
        self.stats[STAT_MR] = MR

    def getAS(self):
        return self.stats[STAT_AS]

    def setAS(self, AS):
        self.stats[STAT_AS] = AS

    def getMS(self):
        return self.stats[STAT_MS]

    def setMS(self, MS):
        self.stats[STAT_MS] = MS

    def getGOLD(self):
        return self.stats[STAT_GOLD]

    def setGOLD(self, GOLD):
        self.stats[STAT_GOLD] = GOLD

    def getStat(self, key):
        return self.stats[key]

    def setStat(self, key, value):
        self.stats[key] = value

    def changeStat(self, key, value, blockMsg = False, blockStatLimit = False):
        if key != STAT_ID and key != STAT_NAME and key != STAT_AS:
            self.setStat(key, math.ceil(self.getStat(key) + value))
            if math.ceil(value) != 0 and blockMsg == False:
                afterChangeStat(math.ceil(value), key, self.getName())
        elif key == STAT_AS:
            self.setStat(key, self.getStat(key) + value)
            if value != 0 and blockMsg == False:
                afterChangeStat(value, key, self.getName())
        if not blockStatLimit:
            self.statLimit()

    def statLimit(self):
        if self.getHP() > self.getMAXHP():
            self.setHP(self.getMAXHP())
        if self.getMana() > self.getMAXMana():
            self.setMana(self.getMAXMana())
        self.setAS(round(self.getAS(), 2))

    def isAlive(self):
        if self.getHP() <= 0:
            return False
        return True

    def doubleStats(self):
        for key, value in self.stats.items():
            self.changeStat(key, value)


    def __str__(self):
        text = ""
        for key in self.stats.keys():
            text = text + key + ": " + str(self.getStat(key)) + " |"
        return text
