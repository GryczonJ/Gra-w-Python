import random

from BasicClasses.dictionary import *

def backpackEffectProceed(user, statList: list):
    if user.getEffectByKey(EFFECT_UNRELIABLE_BACKPACK).isActive():
        for statName in statList:
            if random.randint(0, 100) < 15:
                statValue = user.getStat(statName) * 0.01
                user.changeStat(statName, -statValue)

def dictionaryHelper(statDict: dict, key: str, value: float):
    if key in statDict:
        statDict[key] += value
    else:
        statDict[key] = value

def stateEffects(user):
    for effect in user.getEffects():
        if not effect.getState() and effect.isActive():
            effectTable(effect)

def passingEffects(user):
    for effect in user.getEffects():
        if effect.isActive() and not effect.getPassive():
            effect.changeCount(-1)

def restoreStats(effect):

    user = effect.getEffectOwner()

    if not user.getEffectByKey(EFFECT_PHARAOH_FORM).isActive():
        user.getAbilityByIndex(5).setDefCD(user.getAbilityByIndex(5).getBaseCD())

    for key, value in user.tempStats[effect.getName()].items():
        user.changeStat(key, value)
    user.delTempStatByKey(effect.getName())

def effectTable(effect):

    name = effect.getName()
    user = effect.getEffectOwner()

    if not (name in user.tempStats) and not (effect.getStealValues()):
        user.tempStats[name] = {}

    # Antybiotyk
    if name == EFFECT_ANTIBIOTIC:
        HPReg = user.getHPREG() * 1.5
        dictionaryHelper(user.tempStats[name], STAT_HPREG, -HPReg)
        user.changeStat(STAT_HPREG, HPReg)
    # Postarzenie
    elif name == EFFECT_AGEING:
        dictionaryHelper(user.tempStats[name], STAT_AS, 0.5)
        dictionaryHelper(user.tempStats[name], STAT_MS, 30)
        user.changeStat(STAT_AS, -0.5)
        user.changeStat(STAT_MS, -30)
    # Krwawienie
    elif name == EFFECT_BLEED:
        dmg = user.getMAXHP() * 0.1
        print("Obrażenia krwawienia:")
        user.changeStat(STAT_HP, -dmg)
    # Zawieszenie broni
    elif name == EFFECT_CEASEFIRE:
        ad = user.getAD() * 0.5
        ap = user.getAP() * 0.5
        dictionaryHelper(user.tempStats[name], STAT_AD, ad)
        dictionaryHelper(user.tempStats[name], STAT_AP, ap)
        user.changeStat(STAT_AD, -ad)
        user.changeStat(STAT_AP, -ap)
    # Zabójcza Choroba
    elif name == EFFECT_DEADLY_VIRUS:
        print("", end='')
    # Obrona pana
    elif name == EFFECT_DEFENSE_OF_MR:
        print("", end='')
    # Rozbrojenie
    elif name == EFFECT_DISARM:
        dictionaryHelper(user.tempStats[name], STAT_AR, 15)
        dictionaryHelper(user.tempStats[name], STAT_MR, 15)
        user.changeStat(STAT_AR, -15)
        user.changeStat(STAT_MR, -15)
    # Wyczerpanie
    elif name == EFFECT_EXHAUSTION:
        dictionaryHelper(user.tempStats[name], STAT_AR, user.getAR())
        dictionaryHelper(user.tempStats[name], STAT_MR, user.getMR())
        user.changeStat(STAT_AR, -user.getAR())
        user.changeStat(STAT_MR, -user.getMR())
    # Furia
    elif name == EFFECT_FURY:
        ad = user.getAD() * 0.1
        dictionaryHelper(user.tempStats[name], STAT_CRIT, -5)
        dictionaryHelper(user.tempStats[name], STAT_AD, -ad)
        dictionaryHelper(user.tempStats[name], STAT_MS, -20)
        print("Premie od furii ")
        user.changeStat(STAT_CRIT, 5)
        user.changeStat(STAT_AD, ad)
        user.changeStat(STAT_MS, 20)
    # Ukrycie
    elif name == EFFECT_HIDE:
        print("", end='')
    # Dziurawa kieszeń
    elif name == EFFECT_HOLE_POCKET:
        gold = user.getGOLD() * 0.1
        print("Zgubiłeś pieniądze: ")
        user.changeStat(STAT_GOLD, -gold)
    # Szczęście
    elif name == EFFECT_LUCK:
        print("", end='')
    # Obnażenie
    elif name == EFFECT_PERC_DISARM:
        ar = user.getAR() * 0.15
        mr = user.getMR() * 0.15
        dictionaryHelper(user.tempStats[name], STAT_AR, ar)
        dictionaryHelper(user.tempStats[name], STAT_MR, mr)
        user.changeStat(STAT_AR, -ar)
        user.changeStat(STAT_MR, -mr)
    # Lot pantheona
    elif name == EFFECT_PANTHEON_FLIGHT:
        print("", end='')
    # Postać faraona
    elif name == EFFECT_PHARAOH_FORM:
        dictionaryHelper(user.tempStats[name], STAT_MAXHP, -50)
        dictionaryHelper(user.tempStats[name], STAT_HP, -50)
        dictionaryHelper(user.tempStats[name], STAT_AR, -20)
        dictionaryHelper(user.tempStats[name], STAT_MR, -20)
        user.changeStat(STAT_MAXHP, 50)
        user.changeStat(STAT_HP, 50)
        user.changeStat(STAT_AR, 20)
        user.changeStat(STAT_MR, 20)
        user.getAbilityByIndex(5).setDefCD(1)
    # Zatrucie
    elif name == EFFECT_POISON:
        dmg = user.getMAXHP() * 0.1
        dictionaryHelper(user.tempStats[name], STAT_MAXHP, dmg)
        print("Obrażenie od trucizny: ")
        user.changeStat(STAT_MAXHP, -dmg)
    # Wzmocniona zdolność
    elif name == EFFECT_POWER_ABILITY:
        print("", end='')
    # Święta tarcza
    elif name == EFFECT_SACRED_SHIELD:
        print("", end='')
    # Tarczowanie
    elif name == EFFECT_SHIELDING:
        print("", end='')
    # Wyciszenie
    elif name == EFFECT_SILENCE:
        if len(user.getAbilities()) > 7:
            user.getAbilityByIndex(5).changeCurrCD(1)
            user.getAbilityByIndex(6).changeCurrCD(1)
            user.getAbilityByIndex(7).changeCurrCD(1)
            user.getAbilityByIndex(8).changeCurrCD(1)
    # Spowolnienie
    elif name == EFFECT_SLOWDOWN:
        dictionaryHelper(user.tempStats[name], STAT_MS, 50)
        user.changeStat(STAT_MS, -50)
    # Pobudzenie
    elif name == EFFECT_STIMULATION:
        dictionaryHelper(user.tempStats[name], STAT_AS, -0.5)
        dictionaryHelper(user.tempStats[name], STAT_MS, -35)
        user.changeStat(STAT_AS, 0.5)
        user.changeStat(STAT_MS, 35)
    # Ogłuszenie
    elif name == EFFECT_STUN:
        print("", end='')
    # Prawdziwe widzenie
    elif name == EFFECT_TRUE_VISION:
        print("", end='')
    # Zawodny plecak
    elif name == EFFECT_UNRELIABLE_BACKPACK:
        print("", end='')