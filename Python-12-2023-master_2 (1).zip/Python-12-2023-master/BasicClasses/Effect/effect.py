from BasicClasses.Effect.functions import *
class Effect:

    def __init__(self, name: str,
                 count: int = 0, passive: bool = False,
                 state: bool = False, stealValues: bool = False,
                 negative: bool = False, quickCast: bool = False,
                 blockActions: bool = False):

        self.info = {
            "Name"          : name,         # Nazwa efektu
            "Count"         : count,        # Czas trwania
            "EffectDict"    : dict(),       # Działanie efektu
            "Passive"       : passive,      # True: Redukuje się po skorzystaniu
                                            # False: Redukuje się na początku tury
            "State"         : state,        # True: Jednorazowy efekt
                                            # False: Powtarzany na koniec rundy
            "StealValues"   : stealValues,  # True: Wartości przepadają na zawsze
                                            # False: Powrót wartości na koniec działania efektu
            "Negative"      : negative,     # True: Osłabienie
                                            # False: Wzmocnienie
            "QuickCast"     : quickCast,    # True: Wywołanie efektu od razu, po wzmocnieniu
                                            # False: Dopiero na koniec tury
            "BlockActions"  : blockActions  # True: Nie można wykonać akcji
                                            # False: Można wykonać akcję
        }

        self.effectOwner = None

    def setName(self, name: str):
        self.info["Name"] = name

    def getName(self) -> str:
        return self.info["Name"]

    def setCount(self, count: int):
        self.info["Count"] = count

    def getCount(self) -> int:
        return self.info["Count"]

    def changeCount(self, value: int):
        if value > 0:
            print(self.getEffectOwner().getName() + " otrzymał " + self.getName() + ": " + str(value))
            if self.getQuickCast():
                effectTable(self)
        self.info["Count"] += value
        if not self.isActive() and not self.getStealValues():
            restoreStats(self)
        if self.getName() == EFFECT_DEADLY_VIRUS and not self.isActive():
            if value == -10:
                self.setCount(0)
            else:
                self.effectOwner.setHP(0)


    def setEffectDict(self, effectDict: dict):
        self.info["EffectDict"] = effectDict

    def getEffectDict(self) -> dict:
        return self.info["EffectDict"]

    def setPassive(self, passive: bool):
        self.info["Passive"] = passive

    def getPassive(self) -> bool:
        return self.info["Passive"]

    def setState(self, state: bool):
        self.info["State"] = state

    def getState(self) -> bool:
        return self.info["State"]

    def setStealValues(self, stealValues: bool):
        self.info["StealValues"] = stealValues

    def getStealValues(self) -> bool:
        return self.info["StealValues"]

    def setNegative(self, negative: bool):
        self.info["Negative"] = negative

    def getNegative(self) -> bool:
        return self.info["Negative"]

    def setQuickCast(self, quickCast: bool):
        self.info["QuickCast"] = quickCast

    def getQuickCast(self) -> bool:
        return self.info["QuickCast"]

    def setBlockActions(self, blockActions: bool):
        self.info["BlockActions"] = blockActions

    def getBlockActions(self) -> bool:
        return self.info["BlockActions"]

    def isActive(self) -> bool:
        if self.getCount() > 0:
            return True
        return False

    def setEffectOwner(self, effectOwner):
        self.effectOwner = effectOwner

    def getEffectOwner(self):
        return self.effectOwner

    def reduceCount(self):
        if self.isActive() and not self.getPassive():
            self.changeCount(-1)