from BasicClasses.dictionary import *
from BasicClasses.Effect.effect import Effect

def prepareEffectList(user):

    # Postarzenie
    effect = Effect(name=EFFECT_AGEING, state=True, negative=True, quickCast=True)
    user.addEffect(effect)

    #Antybiotyk
    effect = Effect(name=EFFECT_ANTIBIOTIC, state=True, quickCast=True)
    user.addEffect(effect)

    # Krwawienie
    effect = Effect(name=EFFECT_BLEED, stealValues=True, negative=True, quickCast=True)
    user.addEffect(effect)

    # Zawieszenie broni
    effect = Effect(name=EFFECT_CEASEFIRE, state=True, negative=True, quickCast=True)
    user.addEffect(effect)

    # Zabójcza Choroba
    effect = Effect(name=EFFECT_DEADLY_VIRUS, state=True, negative=True, stealValues=True)
    user.addEffect(effect)

    # Obrona pana
    effect = Effect(name=EFFECT_DEFENSE_OF_MR, stealValues=True)
    user.addEffect(effect)

    # Rozbrojenie
    effect = Effect(name=EFFECT_DISARM, state=True, negative=True, quickCast=True)
    user.addEffect(effect)

    # Wyczerpanie
    effect = Effect(name=EFFECT_EXHAUSTION, state=True, negative=True, quickCast=True, blockActions=True)
    user.addEffect(effect)

    # Furia
    effect = Effect(name=EFFECT_FURY, quickCast=True)
    user.addEffect(effect)

    # Ukrycie
    effect = Effect(name=EFFECT_HIDE, stealValues=True)
    user.addEffect(effect)

    # Dziurawa kieszeń
    effect = Effect(name=EFFECT_HOLE_POCKET, stealValues=True, negative=True, quickCast=True)
    user.addEffect(effect)

    # Szczęście
    effect = Effect(name=EFFECT_LUCK, stealValues=True)
    user.addEffect(effect)

    # Obnażenie
    effect = Effect(name=EFFECT_PERC_DISARM, state=True, negative=True, quickCast=True)
    user.addEffect(effect)

    # Lot pantheona
    effect = Effect(name=EFFECT_PANTHEON_FLIGHT, blockActions=True, stealValues=True)
    user.addEffect(effect)

    # Postać faraona
    effect = Effect(name=EFFECT_PHARAOH_FORM, state=True, quickCast=True)
    user.addEffect(effect)

    # Zatrucie
    effect = Effect(name=EFFECT_POISON, negative=True, quickCast=True)
    user.addEffect(effect)

    # Wzmocniona zdolność
    effect = Effect(name=EFFECT_POWER_ABILITY, passive=True, stealValues=True)
    user.addEffect(effect)

    # Święta tarcza
    effect = Effect(name=EFFECT_SACRED_SHIELD, passive=True, stealValues=True)
    user.addEffect(effect)

    # Tarczowanie
    effect = Effect(name=EFFECT_SHIELDING, stealValues=True)
    user.addEffect(effect)

    # Wyciszenie
    effect = Effect(name=EFFECT_SILENCE, negative=True, quickCast=True, stealValues=True)
    user.addEffect(effect)

    # Spowolnienie
    effect = Effect(name=EFFECT_SLOWDOWN, state=True, negative=True, quickCast=True)
    user.addEffect(effect)

    #Pobudzenie
    effect = Effect(name=EFFECT_STIMULATION, state=True, quickCast=True)
    user.addEffect(effect)

    # Ogłuszenie
    effect = Effect(name=EFFECT_STUN, passive=True, blockActions=True, stealValues=True)
    user.addEffect(effect)

    # Prawdziwe widzenie
    effect = Effect(name=EFFECT_TRUE_VISION, stealValues=True)
    user.addEffect(effect)

    #Zawodny plecak
    effect = Effect(name=EFFECT_UNRELIABLE_BACKPACK, stealValues=True, negative=True)
    user.addEffect(effect)

    for effect in user.getEffects():
        effect.setEffectOwner(user)