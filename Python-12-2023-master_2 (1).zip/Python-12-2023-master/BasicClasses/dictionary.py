########## STATS ##########

STAT_ID         = "ID"
STAT_NAME       = "Name"
STAT_HP         = "HP"
STAT_MAXHP      = "MAXHP"
STAT_HPREG      = "HPREG"
STAT_MANA       = "Mana"
STAT_MAXMANA    = "MAXMana"
STAT_MANAREG    = "ManaREG"
STAT_AD         = "AD"
STAT_AP         = "AP"
STAT_AR         = "AR"
STAT_MR         = "MR"
STAT_CRIT       = "CRIT"
STAT_MS         = "MS"
STAT_AS         = "AS"
STAT_GOLD       = "GOLD"

STAT_KEYS = [STAT_HP, STAT_MAXHP, STAT_HPREG,
             STAT_MANA, STAT_MAXMANA, STAT_MANAREG,
             STAT_AD, STAT_AP, STAT_AR, STAT_MR,
             STAT_CRIT, STAT_MS, STAT_AS, STAT_GOLD]

########## EFFECTS ##########

EFFECT_AGEING           = "Postarzenie"         # Osłabienie: -0.5 AS, -30 MS (Powraca)
EFFECT_ANTIBIOTIC       = "Antybiotyk"          # Wzmocnienie: +150% HPREG (Powraca)
EFFECT_BLEED            = "Krwawienie"          # Osłabienie (cykliczne): -10% MAXHP (MAXHP się nie zmienia)
EFFECT_CEASEFIRE        = "Zawieszenie Broni"   # Osłabienie: -50% AP, -50% AD (Powraca)
EFFECT_DEADLY_VIRUS     = "Zabójcza Choroba"    # Osłabienie: Giniesz za określoną liczbę rund
EFFECT_DEFENSE_OF_MR    = "Obrona Pana"         # Neutralne: Przyjmowanie obrażeń zamiast właściciela
EFFECT_DISARM           = "Rozbrojenie"         # Osłabienie: -15 MR, -15 AR (Powraca)
EFFECT_EXHAUSTION       = "Wyczerpanie"         # Osłabienie: -100% AR, -100% MR (Powraca)
EFFECT_FURY             = "Furia"               # Wzmocnienie (cykliczne): +5 CRIT, +10% AD, +10% AS, +20 MS (Powraca)
EFFECT_HIDE             = "Ukrycie"             # Neutralne: Nie można zostać obranym za cel
EFFECT_HOLE_POCKET      = "Dziurawa Kieszeń"    # Osłabienie (cykliczne): -10% GOLD
EFFECT_LUCK             = "Szczęście"           # Wzmocnienie: Zwiększa szczęście
EFFECT_PERC_DISARM      = "Obnażenie"           # Osłabienie: -15% AR, -15% MR (Powraca)
EFFECT_PANTHEON_FLIGHT  = "Lot Pantheona"       # Neutralne: Jesteś poza zasięgiem wrogów
EFFECT_PHARAOH_FORM     = "Postać Faraona"      # Wzmocnienie: +50 HP, +50 MAXHP, +20 AR, +20 MR, Czas zdolności: Q - 1 tura (Powraca)
EFFECT_POISON           = "Zatrucie"            # Osłabienie (cykliczne): - 10% MAXHP (Powraca)
EFFECT_POWER_ABILITY    = "Wzmocniona Zdolność" # Wzmocnienie: Aktywuje wzmocnioną wersję umiejętności
EFFECT_SACRED_SHIELD    = "Święta Tarcza"       # Wzmocnienie: Jednokrotne blokowanie obrażeń
EFFECT_SHIELDING        = "Tarczowanie"         # Wzmocnienie: Blokowanie obrażeń przez całą turę
EFFECT_SILENCE          = "Wyciszenie"          # Osłabienie: Zwiększenie czasu odnowienia umiejętności o 1 turę
EFFECT_SLOWDOWN         = "Spowolnienie"        # Osłabienie: -50 MS
EFFECT_STIMULATION      = "Pobudzenie"          # Wzmocnienie: +0.5 AS, +35 MS (Powraca)
EFFECT_STUN             = "Ogłuszenie"          # Osłabienie: Nie możesz wykonać żadnej akcji
EFFECT_TRUE_VISION      = "Prawdziwe widzenie"  # Osłabienie: Zawsze jesteś w zasięgu wrogów
EFFECT_UNRELIABLE_BACKPACK = "Zawodny Plecak"   # Osłabienie: W momencie zadania/otrzymania obrażeń, masz szansę, na utratę statystyk (15% szans - utrata: 1%)

########## EVENTS ##########

EVENT_CRAZY_WEATHER         = "Haotyczna Pogoda"
EVENT_DEATH_WAVE            = "Fala Śmierci"
EVENT_DOUBLE_FARM           = "Podwójna Farma"
EVENT_FIRE_RAIN             = "Deszcz Ognia"
EVENT_GOLD_FEVER            = "Gorączka Złota"
EVENT_HEALTH_AURA           = "Aura Zdrowia"
EVENT_MISSILE_INBOUND       = "Rakieta Balistyczna"
EVENT_HELPFUL_ARMOURER      = "Pomocny Płatnerz"
EVENT_WANDERING_BLACKSMITH  = "Wędrowny Kowal"
EVENT_TANK_ADVANTAGE        = "Przewaga Tanków"
EVENT_WARRIOR_ADVANTAGE     = "Przewaga Wojowników"
EVENT_MAGE_ADVANTAGE        = "Przewaga Czarodziejów"
EVENT_SPRINTER_ADVANTAGE    = "Przewaga Sprinterów"
EVENT_LOST_MERCHANT         = "Zagubiony Kupiec"
EVENT_ANCIENT_HERBALIST     = "Starożytny Zielarz"
EVENT_WOODLAND_RANGER       = "Leśny Strażnik"
EVENT_MUDDY_SWAMP           = "Błotniste Bagno"

EVENT_LIST = [EVENT_CRAZY_WEATHER, EVENT_DEATH_WAVE, EVENT_DOUBLE_FARM, EVENT_FIRE_RAIN, EVENT_GOLD_FEVER,
              EVENT_HEALTH_AURA, EVENT_MISSILE_INBOUND, EVENT_HELPFUL_ARMOURER, EVENT_WANDERING_BLACKSMITH,
              EVENT_TANK_ADVANTAGE, EVENT_WARRIOR_ADVANTAGE, EVENT_MAGE_ADVANTAGE, EVENT_SPRINTER_ADVANTAGE,
              EVENT_LOST_MERCHANT, EVENT_ANCIENT_HERBALIST, EVENT_WOODLAND_RANGER, EVENT_MUDDY_SWAMP]

########## MODIFICATIONS ##########

MODIFICATION_CHAOTIC_WEATHER    = "Chaotyczna rozgrywka"
MODIFICATION_DOUBLE_TROUBLE     = "Podwójne kłopoty"
MODIFICATION_GOOD_BEGINNING     = "Dobry początek"
MODIFICATION_METEOR_SHOWER      = "Deszcz Meteorów"
MODIFICATION_ONE_SHOT_CONTEST   = "Zawody w OneShotowaniu"
MODIFICATION_TOXIC_FUMES        = "Toksyczne Opary"