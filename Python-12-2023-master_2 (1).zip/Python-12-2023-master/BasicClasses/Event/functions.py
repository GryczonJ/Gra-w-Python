import random
from BasicClasses.dictionary import *
from NeutralChampions.Shrek.shrek import Shrek

def eventTable(user):

    for eventName in user.getActualEvents():

        # Haotyczna pogoda
        if eventName == EVENT_CRAZY_WEATHER:
            index = random.randint(0, len(user.getEffects()) - 1)
            key = list(user.getEffects())[index]
            user.getEffectByKey(key.getName()).changeCount(2)
        # Fala Śmierci
        elif eventName == EVENT_DEATH_WAVE:
            user.getEffectByKey(EFFECT_DEADLY_VIRUS).changeCount(10)
        # Podwójna Farma
        elif eventName == EVENT_DOUBLE_FARM:
            print("", end='')
        # Deszcz Ognia
        elif eventName == EVENT_FIRE_RAIN:
            user.getEffectByKey(EFFECT_BLEED).changeCount(1)
        # Gorączka Złota
        elif eventName == EVENT_GOLD_FEVER:
            gold_value = random.randint(200, 500)
            user.changeStat(STAT_GOLD, gold_value)
        # Aura Zdrowia
        elif eventName == EVENT_HEALTH_AURA:
            hp_value = user.getMAXHP() - user.getHP()
            user.changeStat(STAT_HP, hp_value)
        # Rakieta Balistyczna
        elif eventName == EVENT_MISSILE_INBOUND:
            user.changeStat(STAT_HP, -40)
        # Pomocny Płatnerz
        elif eventName == EVENT_HELPFUL_ARMOURER:
           ar_value = user.getAR() * 0.1
           mr_value = user.getMR() * 0.1
           user.changeStat(STAT_AR, ar_value)
           user.changeStat(STAT_MR, mr_value)
        # Wędrowny Kowal
        elif eventName == EVENT_WANDERING_BLACKSMITH:
           ad_value = user.getAD() * 0.15
           ap_value = user.getAP() * 0.15
           user.changeStat(STAT_AD, ad_value)
           user.changeStat(STAT_AP, ap_value)
        # Przewaga Tanków
        elif eventName == EVENT_TANK_ADVANTAGE:
            ar_value = user.getMAXHP() * 0.1
            mr_value = user.getMAXHP() * 0.08
            user.changeStat(STAT_AR, ar_value)
            user.changeStat(STAT_MR, mr_value)
        # Przewaga Wojowników
        elif eventName == EVENT_WARRIOR_ADVANTAGE:
            crit_value = user.getAD() * 0.075
            as_value = user.getAD() * 0.0036
            user.changeStat(STAT_CRIT, crit_value)
            user.changeStat(STAT_AS, as_value)
        # Przewaga Czarodziejów
        elif eventName == EVENT_MAGE_ADVANTAGE:
            hp_value = user.getAP() * 0.4
            mana_value = user.getAP() * 0.2
            user.changeStat(STAT_MAXHP, hp_value)
            user.changeStat(STAT_MAXMANA, mana_value)
        # Przewaga Sprinterów
        elif eventName == EVENT_SPRINTER_ADVANTAGE:
            ad_ap_value = user.getAS() * 2 * user.getMS() * 0.03
            user.changeStat(STAT_AD, ad_ap_value)
            user.changeStat(STAT_AP, ad_ap_value)
        # Zagubiony Kupiec
        elif eventName == EVENT_LOST_MERCHANT:
            user.changeShopToken(1)
        # Starożytny Zielarz
        elif eventName == EVENT_ANCIENT_HERBALIST:
            for effect in user.getEffects():
                if effect.isActive() and effect.getNegative():
                    effect.changeCount(-1)
        # Leśny Strażnik
        elif eventName == EVENT_WOODLAND_RANGER:
            user.changeStat(STAT_AS, 0.25)
            user.changeStat(STAT_MS, 40)
        # Błotnistge Bagno
        elif eventName == EVENT_MUDDY_SWAMP:
            for player in user.getPlayers():
                if isinstance(player, Shrek):
                    return
            shrek = Shrek(len(user.getPlayers()), user.getPlayers())
            tempPlayers = [shrek]
            tempPlayers.extend(user.getPlayers())
            shrek.setPlayers(tempPlayers)
            for player in user.getPlayers():
                player.setPlayers(tempPlayers.copy())


